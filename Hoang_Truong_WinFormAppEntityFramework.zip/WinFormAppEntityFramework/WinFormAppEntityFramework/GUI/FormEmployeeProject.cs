﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormAppEntityFramework.VALIDATION;
using WinFormAppEntityFramework.Model;
namespace WinFormAppEntityFramework
{
    public partial class FormEmployeeProject : Form
    {
        int chosenIndex = -1;
        public FormEmployeeProject()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {

            var asking = MessageBox.Show("Do you want to exit the application", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (asking == DialogResult.Yes)
            {
                MessageBox.Show("Thank you for using our application", "Exit", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Exit();
            }
        }

        private void buttonList_Click(object sender, EventArgs e)
        {
           
            listViewEmployee.Items.Clear();
            Employee em = new Employee();
            List<Employee> listE = em.GetAllEmployees();

            foreach (Employee emp in listE)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(emp.EmployeeId));
                item.SubItems.Add(emp.FirstName);
                item.SubItems.Add(emp.LastName);
                item.SubItems.Add(emp.PhoneNumber);
                item.SubItems.Add(emp.Email);
                listViewEmployee.Items.Add(item);
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            using (EmployeeProjectDBEntities db = new EmployeeProjectDBEntities())
            {
                if (Validator.IsCorrectFormatEmpID(textBoxEmployeeId.Text.Trim(), 4))
                {
                    if (Validator.IsCorrectFormatPhoneNumber(textBoxPhoneNumber.Text.Trim()))
                    {
                        try
                        {
                            Employee emp = new Employee();
                            emp.EmployeeId = Convert.ToInt32(textBoxEmployeeId.Text.Trim());
                            emp.FirstName = textBoxFirstName.Text.Trim();
                            emp.LastName = textBoxLastName.Text.Trim();
                            emp.PhoneNumber = textBoxPhoneNumber.Text.Trim();
                            emp.Email = textBoxEmail.Text.Trim();
                            db.Employees.Add(emp);
                            db.SaveChanges();
                            MessageBox.Show($"Adding Employee successfully\nHis/Her information:\n\n{emp}", "Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        }
                        catch (DbUpdateException)
                        {
                            MessageBox.Show("Your Employee ID has already been existed. Please choose another one", "Invalid Employee ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            textBoxEmployeeId.Clear();
                        }


                    }
                    else
                    {
                        textBoxPhoneNumber.Text = "(___)___-____";
                        MessageBox.Show("Your Phone Number must be in the correct format: (___)___-____", "Wrong Format", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Your Employee ID must be 4 digits", "Wrong Format", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxEmployeeId.Clear();
                }
            }

        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            using (EmployeeProjectDBEntities db = new EmployeeProjectDBEntities())
            {
                try
                {
                    Employee emp = db.Employees.Find(Convert.ToInt32(textBoxEmployeeId.Text.Trim()));


                    var asking = MessageBox.Show("Do you want to delete Employee ID" + textBoxEmployeeId.Text.Trim(), "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (asking == DialogResult.Yes)
                    {

                        db.Employees.Remove(emp);
                        MessageBox.Show("The Employee that you choose has been deleted", "Deleting Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        db.SaveChanges();
                    }


                }
                catch (FormatException)
                {

                    MessageBox.Show("Please choose the Employee first that you want to delete by searching operation or choosing in the list below", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            using (EmployeeProjectDBEntities db = new EmployeeProjectDBEntities())
            {
                if (comboBoxSearch.Text.Trim() == "Employee ID")
                {
                    if (Validator.IsCorrectFormatEmpID(textBoxInputInformation.Text.Trim(), 4))
                    {

                        Employee emp = db.Employees.Find(Convert.ToInt32(textBoxInputInformation.Text.Trim()));
                        if (emp != null)
                        {
                            textBoxEmployeeId.Text = Convert.ToString(emp.EmployeeId);
                            textBoxFirstName.Text = emp.FirstName;
                            textBoxLastName.Text = emp.LastName;
                            textBoxEmail.Text = emp.Email;
                            textBoxPhoneNumber.Text = emp.PhoneNumber;
                        }
                        else
                        {
                            MessageBox.Show("The Employee you searched does not exist", "Wrong Format", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Your Employee ID must be 4 digits when searching", "Wrong Format", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            using (EmployeeProjectDBEntities db = new EmployeeProjectDBEntities())
            {
                try
                {
                    Employee emp = db.Employees.Find(Convert.ToInt32(textBoxEmployeeId.Text.Trim()));


                    var asking = MessageBox.Show("Do you want to update Employee ID " + textBoxEmployeeId.Text.Trim(), "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (asking == DialogResult.Yes)
                    {

                        emp.FirstName = textBoxFirstName.Text.Trim();
                        emp.LastName = textBoxLastName.Text.Trim();
                        emp.Email = textBoxEmail.Text.Trim();
                        emp.PhoneNumber = textBoxPhoneNumber.Text.Trim();
                        MessageBox.Show($"The Employee that you choose has been updated successfully\nHis/Her new information:\n\n{emp}", "Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        db.SaveChanges();
                    }


                }
                catch (FormatException)
                {

                    MessageBox.Show("Please choose the Employee first that you want to delete by searching operation or choosing in the list below", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void listViewEmployee_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (EmployeeProjectDBEntities da = new EmployeeProjectDBEntities())
            {
                chosenIndex = listViewEmployee.FocusedItem.Index;
                List<Employee> listE = da.Employees.ToList();
                textBoxEmployeeId.Text = Convert.ToString(listE[chosenIndex].EmployeeId);
                textBoxFirstName.Text = listE[chosenIndex].FirstName;
                textBoxLastName.Text = listE[chosenIndex].LastName;
                textBoxEmail.Text = listE[chosenIndex].Email;
                textBoxPhoneNumber.Text = listE[chosenIndex].PhoneNumber;
            }

        }

        
    }
}
