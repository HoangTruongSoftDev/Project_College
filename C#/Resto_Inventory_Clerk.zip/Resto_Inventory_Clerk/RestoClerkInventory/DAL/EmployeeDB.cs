﻿using RestoClerkInventory.BLL;
using RestoClerkInventory.ENUM;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using RestoClerkInventory.SERVICE;
namespace RestoClerkInventory.DAL
{
    public static class EmployeeDB
    {
        public static void InsertRecord(Employee employee)
        {
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdInsert = new SqlCommand("INSERT INTO Employees VALUES (@employeeId, @firstName, @lastName, @email); ", conn);
            cmdInsert.Parameters.AddWithValue("@employeeId", employee.User.UserId);
            cmdInsert.Parameters.AddWithValue("@firstName", employee.FirstName);
            cmdInsert.Parameters.AddWithValue("@lastName", employee.LastName);
            cmdInsert.Parameters.AddWithValue("@email", employee.Email);
            cmdInsert.ExecuteNonQuery();
            conn.Close();
        }
        public static void UpdateRecord(Employee employee)
        {
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdUpdate = new SqlCommand();
            cmdUpdate.CommandText = "UPDATE Employees SET FirstName = @firstName, LastName = @lastName, Email = @email WHERE EmployeeId = @employeeId;";
            cmdUpdate.Connection = conn;
            cmdUpdate.Parameters.AddWithValue("@employeeId", employee.User.UserId);
            cmdUpdate.Parameters.AddWithValue("@firstName", employee.FirstName);
            cmdUpdate.Parameters.AddWithValue("@lastName", employee.LastName);
            cmdUpdate.Parameters.AddWithValue("@email", employee.Email);
            cmdUpdate.ExecuteNonQuery();
            conn.Close();
        }
        public static void DeleteRecord(Employee employee)
        {
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdDelete = new SqlCommand("DELETE FROM Employees WHERE EmployeeId = @employeeId; ", conn);
            cmdDelete.Parameters.AddWithValue("@employeeId", employee.User.UserId);
            cmdDelete.ExecuteNonQuery();
            conn.Close();
        }
        //public static List<Employee> SelectAllRecords()
        //{
        //    List<Employee> listAllEmployees = new List<Employee>();
        //    SqlConnection conn = Service.GetDBConnection();
        //    SqlCommand cmdSelectAll = new SqlCommand("SELECT * FROM Employees;", conn);
        //    SqlDataReader reader = cmdSelectAll.ExecuteReader();
        //    Employee employee;
        //    while (reader.Read())
        //    {
        //        employee = new Employee();
        //        employee.User.UserId = Convert.ToInt32(reader["EmployeeId"]);
        //        employee.FirstName = reader["FirstName"].ToString();
        //        employee.LastName = reader["LastName"].ToString();
        //        employee.Email = reader["Email"].ToString();
        //        listAllEmployees.Add(employee);
        //    }
        //    conn.Close();

        //    if (listAllEmployees.Any())
        //        return listAllEmployees;
        //    return null;
        //}

        public static Employee SelectRecordById(int employeeId)
        {
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdSelectById = new SqlCommand("SELECT Employees.EmployeeId, Employees.FirstName, Employees.LastName, Employees.Email, " +
                                                     "Users.Position, Users.Password " +
                                                     "FROM Employees JOIN Users ON Employees.EmployeeId = Users.UserId " +
                                                     "WHERE Employees.EmployeeId = @employeeId;", conn);
            cmdSelectById.Parameters.AddWithValue("@employeeId", employeeId);
            SqlDataReader reader = cmdSelectById.ExecuteReader();
            Employee employee = null;
            User user;
            if (reader.Read())
            {
                employee = new Employee();
                user = new User();
                user.UserId = Convert.ToInt32(reader["EmployeeId"]);
                user.HashedPassword = reader["HashedPassword"].ToString();
                Position position = new Position();
                if (Enum.TryParse(reader["Position"].ToString(), out position))
                    user.Position = position;
                employee.User = user;
                employee.FirstName = reader["FirstName"].ToString();
                employee.LastName = reader["LastName"].ToString();
                employee.Email = reader["Email"].ToString();               
            }
            return employee;
        }

        public static List<Employee> SelectRecordsByPosition(string inputPosition)
        {
            List<Employee> listAllEmployees = new List<Employee>();
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdSelectByPosition = new SqlCommand();
            cmdSelectByPosition.Connection = conn;
            cmdSelectByPosition.CommandText = "SELECT Employees.EmployeeId, Employees.FirstName, Employees.LastName, Employees.Email, " +
                                                     "Users.Position, Users.Password " +
                                                     "FROM Employees JOIN Users ON Employees.EmployeeId = Users.UserId " +
                                                     "WHERE Users.Position = @position;";
            cmdSelectByPosition.Parameters.AddWithValue("@position", inputPosition);
            SqlDataReader reader = cmdSelectByPosition.ExecuteReader();
            Employee employee;
            User user;
            while (reader.Read())
            {
                employee = new Employee();
                user = new User();
                user.UserId = Convert.ToInt32(reader["EmployeeId"]);
                user.HashedPassword = reader["HashedPassword"].ToString();
                Position position = new Position();
                if (Enum.TryParse(reader["Position"].ToString(), out position))
                    user.Position = position;

                employee.User = user;
                employee.FirstName = reader["FirstName"].ToString();
                employee.LastName = reader["LastName"].ToString();
                employee.Email = reader["Email"].ToString();
                listAllEmployees.Add(employee);
            }
            if (listAllEmployees.Any())
                return listAllEmployees;
            return null;
        }
        public static List<Employee> SelectRecordsByFirstName(string firstName)
        {
            List<Employee> listAllEmployees = new List<Employee>();
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdSelectByPosition = new SqlCommand();
            cmdSelectByPosition.Connection = conn;
            cmdSelectByPosition.CommandText = "SELECT Employees.EmployeeId, Employees.FirstName, Employees.LastName, Employees.Email, " +
                                                     "Users.Position, Users.Password " +
                                                     "FROM Employees JOIN Users ON Employees.EmployeeId = Users.UserId " +
                                                     "WHERE Employees.FirstName = @firstName;";
            cmdSelectByPosition.Parameters.AddWithValue("@firstName", firstName);
            SqlDataReader reader = cmdSelectByPosition.ExecuteReader();
            Employee employee;
            User user;
            while (reader.Read())
            {
                employee = new Employee();
                user = new User();
                user.UserId = Convert.ToInt32(reader["EmployeeId"]);
                user.HashedPassword = reader["HashedPassword"].ToString();
                Position position = new Position();
                if (Enum.TryParse(reader["Position"].ToString(), out position))
                    user.Position = position;

                employee.User = user;
                employee.FirstName = reader["FirstName"].ToString();
                employee.LastName = reader["LastName"].ToString();
                employee.Email = reader["Email"].ToString();
                listAllEmployees.Add(employee);
            }
            if (listAllEmployees.Any())
                return listAllEmployees;
            return null;
        }
        public static List<Employee> SelectRecordsByLastName(string lastName)
        {
            List<Employee> listAllEmployees = new List<Employee>();
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdSelectByPosition = new SqlCommand();
            cmdSelectByPosition.Connection = conn;
            cmdSelectByPosition.CommandText = "SELECT Employees.EmployeeId, Employees.FirstName, Employees.LastName, Employees.Email, " +
                                                     "Users.Position, Users.Password " +
                                                     "FROM Employees JOIN Users ON Employees.EmployeeId = Users.UserId " +
                                                     "WHERE Employees.LastName = @lastName;";
            cmdSelectByPosition.Parameters.AddWithValue("@lastName", lastName);
            SqlDataReader reader = cmdSelectByPosition.ExecuteReader();
            Employee employee;
            User user;
            while (reader.Read())
            {
                employee = new Employee();
                user = new User();
                user.UserId = Convert.ToInt32(reader["EmployeeId"]);
                user.HashedPassword = reader["HashedPassword"].ToString();
                Position position = new Position();
                if (Enum.TryParse(reader["Position"].ToString(), out position))
                    user.Position = position;

                employee.User = user;
                employee.FirstName = reader["FirstName"].ToString();
                employee.LastName = reader["LastName"].ToString();
                employee.Email = reader["Email"].ToString();
                listAllEmployees.Add(employee);
            }
            if (listAllEmployees.Any())
                return listAllEmployees;
            return null;
        }
        public static List<Employee> SelectRecordsByEmail(string email)
        {
            List<Employee> listAllEmployees = new List<Employee>();
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdSelectByPosition = new SqlCommand();
            cmdSelectByPosition.Connection = conn;
            cmdSelectByPosition.CommandText = "SELECT Employees.EmployeeId, Employees.FirstName, Employees.LastName, Employees.Email, " +
                                                     "Users.Position, Users.Password " +
                                                     "FROM Employees JOIN Users ON Employees.EmployeeId = Users.UserId " +
                                                     "WHERE Employees.Email = @email;";
            cmdSelectByPosition.Parameters.AddWithValue("@email", email);
            SqlDataReader reader = cmdSelectByPosition.ExecuteReader();
            Employee employee;
            User user;
            while (reader.Read())
            {
                employee = new Employee();
                user = new User();
                user.UserId = Convert.ToInt32(reader["EmployeeId"]);
                user.HashedPassword = reader["HashedPassword"].ToString();
                Position position = new Position();
                if (Enum.TryParse(reader["Position"].ToString(), out position))
                    user.Position = position;

                employee.User = user;
                employee.FirstName = reader["FirstName"].ToString();
                employee.LastName = reader["LastName"].ToString();
                employee.Email = reader["Email"].ToString();
                listAllEmployees.Add(employee);
            }
            if (listAllEmployees.Any())
                return listAllEmployees;
            return null;
        }
        public static List<Employee> SelectAllRecordsJoinForeignTable()
        {
            List<Employee> listAllEmployees = new List<Employee>();
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdSelectAll = new SqlCommand("SELECT Employees.EmployeeId, Employees.FirstName, Employees.LastName, Employees.Email, " +
                                                     "Users.Position, Users.Password " +
                                                     "FROM Employees JOIN Users ON Employees.EmployeeId = Users.UserId;", conn);
            SqlDataReader reader = cmdSelectAll.ExecuteReader();
            Employee employee;
            User user;
            while (reader.Read())
            {
                employee = new Employee();
                user = new User();
                user.UserId = Convert.ToInt32(reader["EmployeeId"]);
                user.HashedPassword = reader["HashedPassword"].ToString();
                Position position = new Position();
                if (Enum.TryParse(reader["Position"].ToString(),out position))
                    user.Position = position;
                               
                employee.User = user;
                employee.FirstName = reader["FirstName"].ToString();
                employee.LastName = reader["LastName"].ToString();
                employee.Email = reader["Email"].ToString();
                listAllEmployees.Add(employee);
            }
            conn.Close();

            if (listAllEmployees.Any())
                return listAllEmployees;
            return null;
        }
    }
}