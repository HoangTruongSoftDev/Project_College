﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using RestoClerkInventory.BLL;
using RestoClerkInventory.SERVICE;
using RestoClerkInventory.ENUM;
namespace RestoClerkInventory.DAL
{
    public static class UserDB
    {
        public static void InsertRecord(User user)
        {
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdInsert = new SqlCommand("INSERT INTO Users VALUES (@userId, @hashedPassword, @position); ", conn);
            cmdInsert.Parameters.AddWithValue("@userId", user.UserId);
            cmdInsert.Parameters.AddWithValue("@hashedPassword", user.HashedPassword);
            cmdInsert.Parameters.AddWithValue("@position", user.Position.ToString());
            cmdInsert.ExecuteNonQuery();
            conn.Close();
        }
        public static void UpdateRecord(User user)
        {
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdUpdate = new SqlCommand();
            cmdUpdate.CommandText = "UPDATE Users SET HashedPassword = @hashedpassword, Position = @position WHERE UserId = @userId;";
            cmdUpdate.Connection = conn;
            cmdUpdate.Parameters.AddWithValue("@userId", user.UserId);
            cmdUpdate.Parameters.AddWithValue("@hashedpassword", user.HashedPassword);
            cmdUpdate.Parameters.AddWithValue("@position", user.Position.ToString());
            cmdUpdate.ExecuteNonQuery();
            conn.Close();
        }
        public static void DeleteRecord(User user)
        {
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdDelete = new SqlCommand("DELETE FROM Users WHERE UserId = @userId; ", conn);
            cmdDelete.Parameters.AddWithValue("@userId", user.UserId);
            cmdDelete.ExecuteNonQuery();
            conn.Close();
        }
        public static List<User> SelectAllRecords()
        { 
            List<User> listAllUsers = new List<User>(); 
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdSelectAll = new SqlCommand("SELECT * FROM Users; ", conn);
            SqlDataReader reader = cmdSelectAll.ExecuteReader();
            User user;
            while (reader.Read()) 
            {
                user = new User();
                user.UserId = Convert.ToInt32(reader["UserId"]);
                user.HashedPassword = reader["HashedPassword"].ToString();
                Position position = Position.Undefined;
                if (Enum.TryParse(reader["Position"].ToString(), out position))
                    user.Position = position;               
                listAllUsers.Add(user); 
            }
            conn.Close();

            if (listAllUsers.Any())
                return listAllUsers;    
            return null;
            
        }
        public static List<User> SelectRecordsByPosition()
        {
            List<User> listAllUsers = new List<User>();
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdSelectAll = new SqlCommand("SELECT * FROM Users WHERE Position = 'Staff' OR Position = 'Manager'; ", conn);
            SqlDataReader reader = cmdSelectAll.ExecuteReader();
            User user;
            while (reader.Read())
            {
                user = new User();
                user.UserId = Convert.ToInt32(reader["UserId"]);
                user.HashedPassword = reader["HashedPassword"].ToString();
                Position position = Position.Undefined;
                if (Enum.TryParse(reader["Position"].ToString(), out position))
                    user.Position = position;
                listAllUsers.Add(user);
            }
            conn.Close();

            if (listAllUsers.Any())
                return listAllUsers;
            return null;

        }
        public static User SelectById(int userId) 
        {
            SqlConnection conn = Service.GetDBConnection();
            SqlCommand cmdSelectById = new SqlCommand("SELECT * FROM Users WHERE UserId = @userId;", conn);
            cmdSelectById.Parameters.AddWithValue("@userId", userId);
            SqlDataReader reader = cmdSelectById.ExecuteReader();
            User user = null;
            if (reader.Read())
            {
                user = new User();
                user.UserId= Convert.ToInt32(reader["UserId"]);      
                user.HashedPassword = reader["HashedPassword"].ToString();
               
                
                Position position = Position.Undefined;
                if(Enum.TryParse(reader["Position"].ToString(),out position))               
                    user.Position = position;               
            }
            return user;
        }
        
    }
}