﻿namespace PresentationLayer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.listViewMountainBike = new System.Windows.Forms.ListView();
            this.columnHeaderSerialNumberMB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderModelMB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMakeMB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderColorMB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSpeedMB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDateMB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderHeightFromGround = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSuspension = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMountainBikeStyle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderInsuranceMB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewRoadBike = new System.Windows.Forms.ListView();
            this.columnHeaderSerialNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderModel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMake = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderColor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSpeed = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderInsurance = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSeatHeight = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRoadBikeStyle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.labelListBoxRoadBike = new System.Windows.Forms.Label();
            this.listBoxBike = new System.Windows.Forms.ListBox();
            this.labelListBoxMountainBike = new System.Windows.Forms.Label();
            this.labelListBoxBike = new System.Windows.Forms.Label();
            this.toolTipLabelMountainBikeStyle = new System.Windows.Forms.ToolTip(this.components);
            this.labelMountainBikeStyle = new System.Windows.Forms.Label();
            this.toolTipComboBoxRoadBikeStyle = new System.Windows.Forms.ToolTip(this.components);
            this.comboBoxRoadBikeStyle = new System.Windows.Forms.ComboBox();
            this.toolTipLabelRoadBikeStyle = new System.Windows.Forms.ToolTip(this.components);
            this.labelRoadBikeStyle = new System.Windows.Forms.Label();
            this.toolTipTextBoxHeightFromGround = new System.Windows.Forms.ToolTip(this.components);
            this.textBoxHeightFromGround = new System.Windows.Forms.TextBox();
            this.toolTipLabelHeightFromGround = new System.Windows.Forms.ToolTip(this.components);
            this.labelHeightFromGround = new System.Windows.Forms.Label();
            this.toolTipTextBoxSeatHeight = new System.Windows.Forms.ToolTip(this.components);
            this.textBoxSeatHeight = new System.Windows.Forms.TextBox();
            this.toolTipComboBoxSuspension = new System.Windows.Forms.ToolTip(this.components);
            this.comboBoxSuspension = new System.Windows.Forms.ComboBox();
            this.toolTipLabelSeatHeight = new System.Windows.Forms.ToolTip(this.components);
            this.labelSeatHeight = new System.Windows.Forms.Label();
            this.toolTipLabelSuspension = new System.Windows.Forms.ToolTip(this.components);
            this.labelSuspension = new System.Windows.Forms.Label();
            this.toolTipTextBoxSpeedUp = new System.Windows.Forms.ToolTip(this.components);
            this.textBoxSpeedUp = new System.Windows.Forms.TextBox();
            this.toolTipComboBoxMountainBikeStyle = new System.Windows.Forms.ToolTip(this.components);
            this.comboBoxMountainBikeStyle = new System.Windows.Forms.ComboBox();
            this.toolTipLabelSpeedUp = new System.Windows.Forms.ToolTip(this.components);
            this.labelSpeedUp = new System.Windows.Forms.Label();
            this.toolTipLabelSpeed = new System.Windows.Forms.ToolTip(this.components);
            this.labelSpeed = new System.Windows.Forms.Label();
            this.toolTipDateTimePicker = new System.Windows.Forms.ToolTip(this.components);
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.toolTipTextBoxInsurance = new System.Windows.Forms.ToolTip(this.components);
            this.textBoxInsurance = new System.Windows.Forms.TextBox();
            this.toolTipLabelInsurance = new System.Windows.Forms.ToolTip(this.components);
            this.labelInsurance = new System.Windows.Forms.Label();
            this.toolTipComboBoxColor = new System.Windows.Forms.ToolTip(this.components);
            this.comboBoxColor = new System.Windows.Forms.ComboBox();
            this.toolTipLabelColor = new System.Windows.Forms.ToolTip(this.components);
            this.labelColor = new System.Windows.Forms.Label();
            this.toolTipLabelModel = new System.Windows.Forms.ToolTip(this.components);
            this.labelModel = new System.Windows.Forms.Label();
            this.textBoxModel = new System.Windows.Forms.TextBox();
            this.toolTipTextBoxMake = new System.Windows.Forms.ToolTip(this.components);
            this.textBoxMake = new System.Windows.Forms.TextBox();
            this.labelSearch = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.toolTipTextBoxSpeed = new System.Windows.Forms.ToolTip(this.components);
            this.textBoxSpeed = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panelFeature = new System.Windows.Forms.Panel();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.buttonDisplay = new System.Windows.Forms.Button();
            this.comboBoxTypeBike = new System.Windows.Forms.ComboBox();
            this.buttonReset = new System.Windows.Forms.Button();
            this.comboBoxReset = new System.Windows.Forms.ComboBox();
            this.buttonRemove = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.comboBoxClear = new System.Windows.Forms.ComboBox();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.buttonSpeedUp = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.labelDate = new System.Windows.Forms.Label();
            this.tableLayoutPanelInformation = new System.Windows.Forms.TableLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelSerialNumber = new System.Windows.Forms.Label();
            this.textBoxSerialNumber = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.labelMake = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.buttonView = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.mountainBikeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roadBikeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripBike = new System.Windows.Forms.MenuStrip();
            this.toolTipButton = new System.Windows.Forms.ToolTip(this.components);
            this.labelInformation = new System.Windows.Forms.Label();
            this.labelObservation = new System.Windows.Forms.Label();
            this.labelTitleLogin = new System.Windows.Forms.Label();
            this.toolTipLabelMake = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipTextBoxSerialNumber = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipLabelSerialNumber = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipLabelDate = new System.Windows.Forms.ToolTip(this.components);
            this.labelFeature = new System.Windows.Forms.Label();
            this.toolTipComboBoxOption = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipSearch = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipLabel = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipList = new System.Windows.Forms.ToolTip(this.components);
            this.labelCopyRight = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panelFeature.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tableLayoutPanelInformation.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel4.SuspendLayout();
            this.menuStripBike.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.listViewMountainBike);
            this.panel1.Controls.Add(this.listViewRoadBike);
            this.panel1.Controls.Add(this.labelListBoxRoadBike);
            this.panel1.Controls.Add(this.listBoxBike);
            this.panel1.Controls.Add(this.labelListBoxMountainBike);
            this.panel1.Controls.Add(this.labelListBoxBike);
            this.panel1.Location = new System.Drawing.Point(1109, 162);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(777, 778);
            this.panel1.TabIndex = 64;
            // 
            // listViewMountainBike
            // 
            this.listViewMountainBike.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderSerialNumberMB,
            this.columnHeaderModelMB,
            this.columnHeaderMakeMB,
            this.columnHeaderColorMB,
            this.columnHeaderSpeedMB,
            this.columnHeaderDateMB,
            this.columnHeaderHeightFromGround,
            this.columnHeaderSuspension,
            this.columnHeaderMountainBikeStyle,
            this.columnHeaderInsuranceMB});
            this.listViewMountainBike.FullRowSelect = true;
            this.listViewMountainBike.GridLines = true;
            this.listViewMountainBike.HideSelection = false;
            this.listViewMountainBike.Location = new System.Drawing.Point(0, 211);
            this.listViewMountainBike.Name = "listViewMountainBike";
            this.listViewMountainBike.Size = new System.Drawing.Size(774, 271);
            this.listViewMountainBike.TabIndex = 52;
            this.listViewMountainBike.UseCompatibleStateImageBehavior = false;
            this.listViewMountainBike.View = System.Windows.Forms.View.Details;
            this.listViewMountainBike.SelectedIndexChanged += new System.EventHandler(this.listViewMountainBike_SelectedIndexChanged);
            // 
            // columnHeaderSerialNumberMB
            // 
            this.columnHeaderSerialNumberMB.Text = "Serial Number";
            this.columnHeaderSerialNumberMB.Width = 155;
            // 
            // columnHeaderModelMB
            // 
            this.columnHeaderModelMB.Text = "Model";
            this.columnHeaderModelMB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderModelMB.Width = 131;
            // 
            // columnHeaderMakeMB
            // 
            this.columnHeaderMakeMB.Text = "Factory";
            this.columnHeaderMakeMB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderMakeMB.Width = 152;
            // 
            // columnHeaderColorMB
            // 
            this.columnHeaderColorMB.Text = "Color";
            this.columnHeaderColorMB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderColorMB.Width = 130;
            // 
            // columnHeaderSpeedMB
            // 
            this.columnHeaderSpeedMB.Text = "Speed";
            this.columnHeaderSpeedMB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderSpeedMB.Width = 0;
            // 
            // columnHeaderDateMB
            // 
            this.columnHeaderDateMB.Text = "Date";
            this.columnHeaderDateMB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderDateMB.Width = 117;
            // 
            // columnHeaderHeightFromGround
            // 
            this.columnHeaderHeightFromGround.Text = "Height From Ground";
            this.columnHeaderHeightFromGround.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderHeightFromGround.Width = 132;
            // 
            // columnHeaderSuspension
            // 
            this.columnHeaderSuspension.Text = "Suspension";
            this.columnHeaderSuspension.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderSuspension.Width = 140;
            // 
            // columnHeaderMountainBikeStyle
            // 
            this.columnHeaderMountainBikeStyle.Text = "Style";
            this.columnHeaderMountainBikeStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderMountainBikeStyle.Width = 140;
            // 
            // columnHeaderInsuranceMB
            // 
            this.columnHeaderInsuranceMB.Text = "Insurance";
            // 
            // listViewRoadBike
            // 
            this.listViewRoadBike.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderSerialNumber,
            this.columnHeaderModel,
            this.columnHeaderMake,
            this.columnHeaderColor,
            this.columnHeaderSpeed,
            this.columnHeaderDate,
            this.columnHeaderInsurance,
            this.columnHeaderSeatHeight,
            this.columnHeaderRoadBikeStyle});
            this.listViewRoadBike.FullRowSelect = true;
            this.listViewRoadBike.GridLines = true;
            this.listViewRoadBike.HideSelection = false;
            this.listViewRoadBike.Location = new System.Drawing.Point(0, 517);
            this.listViewRoadBike.Name = "listViewRoadBike";
            this.listViewRoadBike.Size = new System.Drawing.Size(774, 261);
            this.listViewRoadBike.TabIndex = 51;
            this.toolTipList.SetToolTip(this.listViewRoadBike, "The Observation of List of Mountain Bikes in Detail");
            this.listViewRoadBike.UseCompatibleStateImageBehavior = false;
            this.listViewRoadBike.View = System.Windows.Forms.View.Details;
            this.listViewRoadBike.SelectedIndexChanged += new System.EventHandler(this.listViewRoadBike_SelectedIndexChanged);
            // 
            // columnHeaderSerialNumber
            // 
            this.columnHeaderSerialNumber.Text = "Serial Number";
            this.columnHeaderSerialNumber.Width = 155;
            // 
            // columnHeaderModel
            // 
            this.columnHeaderModel.Text = "Model";
            this.columnHeaderModel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderModel.Width = 131;
            // 
            // columnHeaderMake
            // 
            this.columnHeaderMake.Text = "Factory";
            this.columnHeaderMake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderMake.Width = 152;
            // 
            // columnHeaderColor
            // 
            this.columnHeaderColor.Text = "Color";
            this.columnHeaderColor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderColor.Width = 130;
            // 
            // columnHeaderSpeed
            // 
            this.columnHeaderSpeed.Text = "Speed";
            this.columnHeaderSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderSpeed.Width = 0;
            // 
            // columnHeaderDate
            // 
            this.columnHeaderDate.Text = "Date";
            this.columnHeaderDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderDate.Width = 117;
            // 
            // columnHeaderInsurance
            // 
            this.columnHeaderInsurance.Text = "Insurance";
            this.columnHeaderInsurance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderInsurance.Width = 132;
            // 
            // columnHeaderSeatHeight
            // 
            this.columnHeaderSeatHeight.Text = "Seat Height";
            this.columnHeaderSeatHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderSeatHeight.Width = 140;
            // 
            // columnHeaderRoadBikeStyle
            // 
            this.columnHeaderRoadBikeStyle.Text = "Style";
            this.columnHeaderRoadBikeStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderRoadBikeStyle.Width = 140;
            // 
            // labelListBoxRoadBike
            // 
            this.labelListBoxRoadBike.AutoSize = true;
            this.labelListBoxRoadBike.ForeColor = System.Drawing.Color.Blue;
            this.labelListBoxRoadBike.Location = new System.Drawing.Point(3, 497);
            this.labelListBoxRoadBike.Name = "labelListBoxRoadBike";
            this.labelListBoxRoadBike.Size = new System.Drawing.Size(166, 16);
            this.labelListBoxRoadBike.TabIndex = 49;
            this.labelListBoxRoadBike.Text = "List of Road Bikes in Detail";
            // 
            // listBoxBike
            // 
            this.listBoxBike.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxBike.FormattingEnabled = true;
            this.listBoxBike.ItemHeight = 16;
            this.listBoxBike.Location = new System.Drawing.Point(0, 19);
            this.listBoxBike.Name = "listBoxBike";
            this.listBoxBike.Size = new System.Drawing.Size(774, 164);
            this.listBoxBike.TabIndex = 33;
            this.toolTipList.SetToolTip(this.listBoxBike, "The Observation of TWO Lists of Bikes: Road Bikes and Mountain Bikes");
            this.listBoxBike.SelectedIndexChanged += new System.EventHandler(this.listBoxBike_SelectedIndexChanged);
            // 
            // labelListBoxMountainBike
            // 
            this.labelListBoxMountainBike.AutoSize = true;
            this.labelListBoxMountainBike.ForeColor = System.Drawing.Color.Blue;
            this.labelListBoxMountainBike.Location = new System.Drawing.Point(-3, 192);
            this.labelListBoxMountainBike.Name = "labelListBoxMountainBike";
            this.labelListBoxMountainBike.Size = new System.Drawing.Size(186, 16);
            this.labelListBoxMountainBike.TabIndex = 50;
            this.labelListBoxMountainBike.Text = "List of Mountain Bikes in Detail";
            this.toolTipList.SetToolTip(this.labelListBoxMountainBike, "The Observation of List of Mountain Bikes in Detail");
            // 
            // labelListBoxBike
            // 
            this.labelListBoxBike.AutoSize = true;
            this.labelListBoxBike.ForeColor = System.Drawing.Color.Blue;
            this.labelListBoxBike.Location = new System.Drawing.Point(-3, 0);
            this.labelListBoxBike.Name = "labelListBoxBike";
            this.labelListBoxBike.Size = new System.Drawing.Size(76, 16);
            this.labelListBoxBike.TabIndex = 48;
            this.labelListBoxBike.Text = "Sumary List";
            // 
            // labelMountainBikeStyle
            // 
            this.labelMountainBikeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelMountainBikeStyle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelMountainBikeStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMountainBikeStyle.Location = new System.Drawing.Point(43, 22);
            this.labelMountainBikeStyle.Name = "labelMountainBikeStyle";
            this.labelMountainBikeStyle.Size = new System.Drawing.Size(173, 70);
            this.labelMountainBikeStyle.TabIndex = 21;
            this.labelMountainBikeStyle.Text = "Mountain Bike Style:";
            this.labelMountainBikeStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelMountainBikeStyle.SetToolTip(this.labelMountainBikeStyle, "The Style of Mountain Bike");
            this.labelMountainBikeStyle.Visible = false;
            // 
            // comboBoxRoadBikeStyle
            // 
            this.comboBoxRoadBikeStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxRoadBikeStyle.FormattingEnabled = true;
            this.comboBoxRoadBikeStyle.Location = new System.Drawing.Point(303, 17);
            this.comboBoxRoadBikeStyle.Name = "comboBoxRoadBikeStyle";
            this.comboBoxRoadBikeStyle.Size = new System.Drawing.Size(185, 28);
            this.comboBoxRoadBikeStyle.TabIndex = 28;
            this.toolTipComboBoxRoadBikeStyle.SetToolTip(this.comboBoxRoadBikeStyle, "Choose the Style of the Road Bike (Only one option)");
            this.comboBoxRoadBikeStyle.Visible = false;
            // 
            // labelRoadBikeStyle
            // 
            this.labelRoadBikeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelRoadBikeStyle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelRoadBikeStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRoadBikeStyle.Location = new System.Drawing.Point(43, 7);
            this.labelRoadBikeStyle.Name = "labelRoadBikeStyle";
            this.labelRoadBikeStyle.Size = new System.Drawing.Size(173, 43);
            this.labelRoadBikeStyle.TabIndex = 23;
            this.labelRoadBikeStyle.Text = "Road Bike Style:";
            this.labelRoadBikeStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelRoadBikeStyle.SetToolTip(this.labelRoadBikeStyle, "The Style of Road Bike");
            this.labelRoadBikeStyle.Visible = false;
            // 
            // textBoxHeightFromGround
            // 
            this.textBoxHeightFromGround.Location = new System.Drawing.Point(303, 17);
            this.textBoxHeightFromGround.Multiline = true;
            this.textBoxHeightFromGround.Name = "textBoxHeightFromGround";
            this.textBoxHeightFromGround.Size = new System.Drawing.Size(185, 39);
            this.textBoxHeightFromGround.TabIndex = 16;
            this.toolTipTextBoxHeightFromGround.SetToolTip(this.textBoxHeightFromGround, "Insert the Height From Ground of the Mountain Bike (Contains only number)");
            this.textBoxHeightFromGround.Visible = false;
            this.textBoxHeightFromGround.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxHeightFromGround_KeyPress);
            // 
            // labelHeightFromGround
            // 
            this.labelHeightFromGround.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelHeightFromGround.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelHeightFromGround.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHeightFromGround.Location = new System.Drawing.Point(43, 0);
            this.labelHeightFromGround.Name = "labelHeightFromGround";
            this.labelHeightFromGround.Size = new System.Drawing.Size(215, 57);
            this.labelHeightFromGround.TabIndex = 9;
            this.labelHeightFromGround.Text = "Height From Ground (m):";
            this.labelHeightFromGround.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelHeightFromGround.SetToolTip(this.labelHeightFromGround, "The Height From Ground of the Mountain Bike");
            this.labelHeightFromGround.Visible = false;
            // 
            // textBoxSeatHeight
            // 
            this.textBoxSeatHeight.Location = new System.Drawing.Point(303, 32);
            this.textBoxSeatHeight.Multiline = true;
            this.textBoxSeatHeight.Name = "textBoxSeatHeight";
            this.textBoxSeatHeight.Size = new System.Drawing.Size(185, 39);
            this.textBoxSeatHeight.TabIndex = 15;
            this.toolTipTextBoxSeatHeight.SetToolTip(this.textBoxSeatHeight, "Insert the Seat Height of the Road Bike (Contains only number)");
            this.textBoxSeatHeight.Visible = false;
            this.textBoxSeatHeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSeatHeight_KeyPress);
            // 
            // comboBoxSuspension
            // 
            this.comboBoxSuspension.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxSuspension.FormattingEnabled = true;
            this.comboBoxSuspension.Location = new System.Drawing.Point(303, 32);
            this.comboBoxSuspension.Name = "comboBoxSuspension";
            this.comboBoxSuspension.Size = new System.Drawing.Size(185, 28);
            this.comboBoxSuspension.TabIndex = 18;
            this.toolTipComboBoxSuspension.SetToolTip(this.comboBoxSuspension, "Choose the Suspension of the Mountain Bike (Only one option)");
            this.comboBoxSuspension.Visible = false;
            // 
            // labelSeatHeight
            // 
            this.labelSeatHeight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelSeatHeight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSeatHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeatHeight.Location = new System.Drawing.Point(43, 32);
            this.labelSeatHeight.Name = "labelSeatHeight";
            this.labelSeatHeight.Size = new System.Drawing.Size(173, 39);
            this.labelSeatHeight.TabIndex = 7;
            this.labelSeatHeight.Text = "Seat Height (m):";
            this.labelSeatHeight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelSeatHeight.SetToolTip(this.labelSeatHeight, "The Seat Height of the Road Bike (Contains only numbers)");
            this.labelSeatHeight.Visible = false;
            // 
            // labelSuspension
            // 
            this.labelSuspension.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelSuspension.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSuspension.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSuspension.Location = new System.Drawing.Point(43, 32);
            this.labelSuspension.Name = "labelSuspension";
            this.labelSuspension.Size = new System.Drawing.Size(173, 39);
            this.labelSuspension.TabIndex = 8;
            this.labelSuspension.Text = "Suspension:";
            this.labelSuspension.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelSuspension.SetToolTip(this.labelSuspension, "The Suspension of the Mountain Bike");
            this.labelSuspension.Visible = false;
            // 
            // textBoxSpeedUp
            // 
            this.textBoxSpeedUp.Location = new System.Drawing.Point(303, 14);
            this.textBoxSpeedUp.Multiline = true;
            this.textBoxSpeedUp.Name = "textBoxSpeedUp";
            this.textBoxSpeedUp.Size = new System.Drawing.Size(185, 39);
            this.textBoxSpeedUp.TabIndex = 14;
            this.toolTipTextBoxSpeedUp.SetToolTip(this.textBoxSpeedUp, "Insert the new Speed of the Bike (Contains the numbers only)");
            this.textBoxSpeedUp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSpeedUp_KeyPress);
            // 
            // comboBoxMountainBikeStyle
            // 
            this.comboBoxMountainBikeStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxMountainBikeStyle.FormattingEnabled = true;
            this.comboBoxMountainBikeStyle.Location = new System.Drawing.Point(291, 46);
            this.comboBoxMountainBikeStyle.Name = "comboBoxMountainBikeStyle";
            this.comboBoxMountainBikeStyle.Size = new System.Drawing.Size(185, 28);
            this.comboBoxMountainBikeStyle.TabIndex = 29;
            this.toolTipComboBoxMountainBikeStyle.SetToolTip(this.comboBoxMountainBikeStyle, "Choose the Style of Mountain Bike (Only one option)");
            this.comboBoxMountainBikeStyle.Visible = false;
            // 
            // labelSpeedUp
            // 
            this.labelSpeedUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelSpeedUp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSpeedUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSpeedUp.Location = new System.Drawing.Point(43, 14);
            this.labelSpeedUp.Name = "labelSpeedUp";
            this.labelSpeedUp.Size = new System.Drawing.Size(183, 39);
            this.labelSpeedUp.TabIndex = 5;
            this.labelSpeedUp.Text = "Speed Up (km/h):";
            this.labelSpeedUp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelSpeedUp.SetToolTip(this.labelSpeedUp, "Insert the new Speed of the Bike to gain the Maximum Speed");
            // 
            // labelSpeed
            // 
            this.labelSpeed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelSpeed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSpeed.Location = new System.Drawing.Point(43, 0);
            this.labelSpeed.Name = "labelSpeed";
            this.labelSpeed.Size = new System.Drawing.Size(173, 39);
            this.labelSpeed.TabIndex = 4;
            this.labelSpeed.Text = "Speed (km/h):";
            this.labelSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelSpeed.SetToolTip(this.labelSpeed, "Initial Speed of the Bike");
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker.Location = new System.Drawing.Point(279, 24);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(185, 26);
            this.dateTimePicker.TabIndex = 27;
            this.toolTipDateTimePicker.SetToolTip(this.dateTimePicker, "Choose the Date producing the Bike (the default Date\r\n is today)");
            // 
            // textBoxInsurance
            // 
            this.textBoxInsurance.Location = new System.Drawing.Point(279, 16);
            this.textBoxInsurance.Multiline = true;
            this.textBoxInsurance.Name = "textBoxInsurance";
            this.textBoxInsurance.Size = new System.Drawing.Size(185, 39);
            this.textBoxInsurance.TabIndex = 20;
            this.toolTipTextBoxInsurance.SetToolTip(this.textBoxInsurance, "Insert the Insurance of the Bike (Contains only Digit and Uppercase Letter)");
            this.textBoxInsurance.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxInsurance_KeyPress);
            // 
            // labelInsurance
            // 
            this.labelInsurance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelInsurance.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelInsurance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInsurance.Location = new System.Drawing.Point(39, 16);
            this.labelInsurance.Name = "labelInsurance";
            this.labelInsurance.Size = new System.Drawing.Size(173, 39);
            this.labelInsurance.TabIndex = 19;
            this.labelInsurance.Text = "Insurance:";
            this.labelInsurance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelInsurance.SetToolTip(this.labelInsurance, "The Insurance of the Bike");
            // 
            // comboBoxColor
            // 
            this.comboBoxColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxColor.FormattingEnabled = true;
            this.comboBoxColor.ItemHeight = 20;
            this.comboBoxColor.Location = new System.Drawing.Point(279, 11);
            this.comboBoxColor.Name = "comboBoxColor";
            this.comboBoxColor.Size = new System.Drawing.Size(185, 28);
            this.comboBoxColor.Sorted = true;
            this.comboBoxColor.TabIndex = 17;
            this.toolTipComboBoxColor.SetToolTip(this.comboBoxColor, "Choose the Color of the Bike (Only one option)");
            // 
            // labelColor
            // 
            this.labelColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelColor.Location = new System.Drawing.Point(39, 11);
            this.labelColor.Name = "labelColor";
            this.labelColor.Size = new System.Drawing.Size(173, 39);
            this.labelColor.TabIndex = 3;
            this.labelColor.Text = "Color:";
            this.labelColor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelColor.SetToolTip(this.labelColor, "The Color of the Bike");
            // 
            // labelModel
            // 
            this.labelModel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelModel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelModel.Location = new System.Drawing.Point(39, 8);
            this.labelModel.Name = "labelModel";
            this.labelModel.Size = new System.Drawing.Size(173, 39);
            this.labelModel.TabIndex = 2;
            this.labelModel.Text = "Model:";
            this.labelModel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelModel.SetToolTip(this.labelModel, "The Model of the Bike");
            // 
            // textBoxModel
            // 
            this.textBoxModel.Location = new System.Drawing.Point(279, 12);
            this.textBoxModel.Multiline = true;
            this.textBoxModel.Name = "textBoxModel";
            this.textBoxModel.Size = new System.Drawing.Size(185, 39);
            this.textBoxModel.TabIndex = 12;
            this.toolTipLabelModel.SetToolTip(this.textBoxModel, "Insert the Model of the Bike");
            // 
            // textBoxMake
            // 
            this.textBoxMake.Location = new System.Drawing.Point(279, 11);
            this.textBoxMake.Multiline = true;
            this.textBoxMake.Name = "textBoxMake";
            this.textBoxMake.Size = new System.Drawing.Size(185, 39);
            this.textBoxMake.TabIndex = 11;
            this.toolTipTextBoxMake.SetToolTip(this.textBoxMake, "Insert the Factory producing the Bike");
            this.textBoxMake.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMake_KeyPress);
            // 
            // labelSearch
            // 
            this.labelSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelSearch.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearch.Location = new System.Drawing.Point(609, 100);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(252, 43);
            this.labelSearch.TabIndex = 31;
            this.labelSearch.Text = "Seach by Serial Number";
            this.labelSearch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipSearch.SetToolTip(this.labelSearch, "Search the Exists Bike based on its Serial Number");
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.labelSpeedUp);
            this.panel10.Controls.Add(this.textBoxSpeedUp);
            this.panel10.Location = new System.Drawing.Point(525, 70);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(515, 65);
            this.panel10.TabIndex = 58;
            // 
            // textBoxSpeed
            // 
            this.textBoxSpeed.Location = new System.Drawing.Point(303, 7);
            this.textBoxSpeed.Multiline = true;
            this.textBoxSpeed.Name = "textBoxSpeed";
            this.textBoxSpeed.Size = new System.Drawing.Size(185, 39);
            this.textBoxSpeed.TabIndex = 13;
            this.toolTipTextBoxSpeed.SetToolTip(this.textBoxSpeed, "Insert the initial Speed of the Bike (Contains numbers only)");
            this.textBoxSpeed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSpeed_KeyPress);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.comboBoxRoadBikeStyle);
            this.panel11.Controls.Add(this.labelRoadBikeStyle);
            this.panel11.Controls.Add(this.labelHeightFromGround);
            this.panel11.Controls.Add(this.textBoxHeightFromGround);
            this.panel11.Location = new System.Drawing.Point(525, 143);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(510, 67);
            this.panel11.TabIndex = 58;
            // 
            // panelFeature
            // 
            this.panelFeature.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelFeature.Controls.Add(this.buttonAdd);
            this.panelFeature.Controls.Add(this.buttonSearch);
            this.panelFeature.Controls.Add(this.buttonDisplay);
            this.panelFeature.Controls.Add(this.labelSearch);
            this.panelFeature.Controls.Add(this.comboBoxTypeBike);
            this.panelFeature.Controls.Add(this.buttonReset);
            this.panelFeature.Controls.Add(this.comboBoxReset);
            this.panelFeature.Controls.Add(this.buttonRemove);
            this.panelFeature.Controls.Add(this.buttonUpdate);
            this.panelFeature.Controls.Add(this.buttonClear);
            this.panelFeature.Controls.Add(this.comboBoxClear);
            this.panelFeature.Controls.Add(this.textBoxSearch);
            this.panelFeature.Controls.Add(this.buttonSpeedUp);
            this.panelFeature.Controls.Add(this.buttonExit);
            this.panelFeature.Location = new System.Drawing.Point(31, 679);
            this.panelFeature.Name = "panelFeature";
            this.panelFeature.Size = new System.Drawing.Size(1057, 261);
            this.panelFeature.TabIndex = 59;
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdd.Location = new System.Drawing.Point(25, 39);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(116, 40);
            this.buttonAdd.TabIndex = 25;
            this.buttonAdd.Text = "ADD";
            this.toolTipButton.SetToolTip(this.buttonAdd, "Click to Add a New Bike into the correct List");
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonSearch
            // 
            this.buttonSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSearch.Location = new System.Drawing.Point(940, 165);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(111, 40);
            this.buttonSearch.TabIndex = 30;
            this.buttonSearch.Text = "SEARCH";
            this.toolTipSearch.SetToolTip(this.buttonSearch, "Click to Search the Existing Bike based on its Serial Number");
            this.buttonSearch.UseVisualStyleBackColor = false;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // buttonDisplay
            // 
            this.buttonDisplay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDisplay.Location = new System.Drawing.Point(25, 93);
            this.buttonDisplay.Name = "buttonDisplay";
            this.buttonDisplay.Size = new System.Drawing.Size(116, 59);
            this.buttonDisplay.TabIndex = 37;
            this.buttonDisplay.Text = "DISPLAY";
            this.toolTipButton.SetToolTip(this.buttonDisplay, "Click to Display the List of Bikes followed by Chosen Option");
            this.buttonDisplay.UseVisualStyleBackColor = false;
            this.buttonDisplay.Click += new System.EventHandler(this.buttonDisplay_Click);
            // 
            // comboBoxTypeBike
            // 
            this.comboBoxTypeBike.FormattingEnabled = true;
            this.comboBoxTypeBike.Location = new System.Drawing.Point(161, 93);
            this.comboBoxTypeBike.Name = "comboBoxTypeBike";
            this.comboBoxTypeBike.Size = new System.Drawing.Size(128, 24);
            this.comboBoxTypeBike.TabIndex = 36;
            this.toolTipComboBoxOption.SetToolTip(this.comboBoxTypeBike, "Choose Option to Display the List of Bikes");
            // 
            // buttonReset
            // 
            this.buttonReset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReset.Location = new System.Drawing.Point(312, 30);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(116, 59);
            this.buttonReset.TabIndex = 43;
            this.buttonReset.Text = "Reset List Bike";
            this.toolTipButton.SetToolTip(this.buttonReset, "Click to Delete Permanently the List of Bikes followed by Option\r\n");
            this.buttonReset.UseVisualStyleBackColor = false;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // comboBoxReset
            // 
            this.comboBoxReset.FormattingEnabled = true;
            this.comboBoxReset.Location = new System.Drawing.Point(457, 39);
            this.comboBoxReset.Name = "comboBoxReset";
            this.comboBoxReset.Size = new System.Drawing.Size(128, 24);
            this.comboBoxReset.TabIndex = 44;
            this.toolTipComboBoxOption.SetToolTip(this.comboBoxReset, "Choose an Option to delete Permanently the List of Bikes");
            // 
            // buttonRemove
            // 
            this.buttonRemove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRemove.Location = new System.Drawing.Point(312, 100);
            this.buttonRemove.Name = "buttonRemove";
            this.buttonRemove.Size = new System.Drawing.Size(116, 59);
            this.buttonRemove.TabIndex = 41;
            this.buttonRemove.Text = "Remove Item";
            this.toolTipButton.SetToolTip(this.buttonRemove, "Add Item");
            this.toolTipComboBoxOption.SetToolTip(this.buttonRemove, "Click to Remove the Selected Bikes from the Correct List of Bike");
            this.buttonRemove.UseVisualStyleBackColor = false;
            this.buttonRemove.Click += new System.EventHandler(this.buttonRemove_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUpdate.Location = new System.Drawing.Point(25, 165);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(116, 40);
            this.buttonUpdate.TabIndex = 38;
            this.buttonUpdate.Text = "UPDATE";
            this.toolTipButton.SetToolTip(this.buttonUpdate, "Click to Update the Selected Bike from the List");
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClear.Location = new System.Drawing.Point(312, 165);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(116, 40);
            this.buttonClear.TabIndex = 40;
            this.buttonClear.Text = "CLEAR";
            this.toolTipButton.SetToolTip(this.buttonClear, "Add Item");
            this.toolTipComboBoxOption.SetToolTip(this.buttonClear, "Click to Clean the User Interface followed by Option");
            this.buttonClear.UseVisualStyleBackColor = false;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // comboBoxClear
            // 
            this.comboBoxClear.FormattingEnabled = true;
            this.comboBoxClear.Location = new System.Drawing.Point(457, 165);
            this.comboBoxClear.Name = "comboBoxClear";
            this.comboBoxClear.Size = new System.Drawing.Size(128, 24);
            this.comboBoxClear.TabIndex = 42;
            this.toolTipComboBoxOption.SetToolTip(this.comboBoxClear, "Choose an Option to Clean the User Interface");
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(880, 100);
            this.textBoxSearch.Multiline = true;
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(171, 43);
            this.textBoxSearch.TabIndex = 32;
            this.toolTipSearch.SetToolTip(this.textBoxSearch, "Insert the Serial Number of the Bike wanted to Find (Only digits from 0 to 9)");
            this.textBoxSearch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSearch_KeyPress);
            // 
            // buttonSpeedUp
            // 
            this.buttonSpeedUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonSpeedUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSpeedUp.Location = new System.Drawing.Point(25, 216);
            this.buttonSpeedUp.Name = "buttonSpeedUp";
            this.buttonSpeedUp.Size = new System.Drawing.Size(116, 40);
            this.buttonSpeedUp.TabIndex = 47;
            this.buttonSpeedUp.Text = "SPEED UP";
            this.toolTipButton.SetToolTip(this.buttonSpeedUp, "Click to Update the new Speed of the Selected Bike");
            this.buttonSpeedUp.UseVisualStyleBackColor = false;
            this.buttonSpeedUp.Click += new System.EventHandler(this.buttonSpeedUp_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.Location = new System.Drawing.Point(312, 214);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(116, 40);
            this.buttonExit.TabIndex = 46;
            this.buttonExit.Text = "EXIT";
            this.toolTipButton.SetToolTip(this.buttonExit, "Add Item");
            this.toolTipComboBoxOption.SetToolTip(this.buttonExit, "Click to Exit the Application of Bike Factory Management");
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.textBoxSeatHeight);
            this.panel12.Controls.Add(this.comboBoxSuspension);
            this.panel12.Controls.Add(this.labelSuspension);
            this.panel12.Controls.Add(this.labelSeatHeight);
            this.panel12.Location = new System.Drawing.Point(525, 218);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(510, 99);
            this.panel12.TabIndex = 58;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.labelDate);
            this.panel9.Controls.Add(this.dateTimePicker);
            this.panel9.Location = new System.Drawing.Point(5, 398);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(499, 67);
            this.panel9.TabIndex = 58;
            // 
            // labelDate
            // 
            this.labelDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDate.Location = new System.Drawing.Point(39, 14);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(183, 39);
            this.labelDate.TabIndex = 6;
            this.labelDate.Text = "Date:";
            this.labelDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelDate.SetToolTip(this.labelDate, "Choose the Date of producing the Bike\r\n\r\n");
            // 
            // tableLayoutPanelInformation
            // 
            this.tableLayoutPanelInformation.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanelInformation.ColumnCount = 2;
            this.tableLayoutPanelInformation.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.2891F));
            this.tableLayoutPanelInformation.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.7109F));
            this.tableLayoutPanelInformation.Controls.Add(this.panel11, 1, 2);
            this.tableLayoutPanelInformation.Controls.Add(this.panel12, 1, 3);
            this.tableLayoutPanelInformation.Controls.Add(this.panel10, 1, 1);
            this.tableLayoutPanelInformation.Controls.Add(this.panel9, 0, 5);
            this.tableLayoutPanelInformation.Controls.Add(this.panel6, 0, 2);
            this.tableLayoutPanelInformation.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanelInformation.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanelInformation.Controls.Add(this.panel5, 0, 1);
            this.tableLayoutPanelInformation.Controls.Add(this.panel7, 0, 3);
            this.tableLayoutPanelInformation.Controls.Add(this.panel8, 0, 4);
            this.tableLayoutPanelInformation.Controls.Add(this.panel4, 1, 4);
            this.tableLayoutPanelInformation.Location = new System.Drawing.Point(31, 162);
            this.tableLayoutPanelInformation.Name = "tableLayoutPanelInformation";
            this.tableLayoutPanelInformation.RowCount = 6;
            this.tableLayoutPanelInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.10744F));
            this.tableLayoutPanelInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.89256F));
            this.tableLayoutPanelInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 73F));
            this.tableLayoutPanelInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 105F));
            this.tableLayoutPanelInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 71F));
            this.tableLayoutPanelInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 84F));
            this.tableLayoutPanelInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelInformation.Size = new System.Drawing.Size(1057, 482);
            this.tableLayoutPanelInformation.TabIndex = 63;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.labelModel);
            this.panel6.Controls.Add(this.textBoxModel);
            this.panel6.Location = new System.Drawing.Point(5, 143);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(499, 54);
            this.panel6.TabIndex = 58;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.labelSpeed);
            this.panel3.Controls.Add(this.textBoxSpeed);
            this.panel3.Location = new System.Drawing.Point(525, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(515, 51);
            this.panel3.TabIndex = 56;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.labelSerialNumber);
            this.panel2.Controls.Add(this.textBoxSerialNumber);
            this.panel2.Location = new System.Drawing.Point(5, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(497, 51);
            this.panel2.TabIndex = 56;
            // 
            // labelSerialNumber
            // 
            this.labelSerialNumber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelSerialNumber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSerialNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSerialNumber.Location = new System.Drawing.Point(39, 3);
            this.labelSerialNumber.Name = "labelSerialNumber";
            this.labelSerialNumber.Size = new System.Drawing.Size(173, 39);
            this.labelSerialNumber.TabIndex = 0;
            this.labelSerialNumber.Text = "Serial Number:";
            this.labelSerialNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelSerialNumber.SetToolTip(this.labelSerialNumber, "Serial Number of the Bike (contain only digit from 0 to 9)");
            // 
            // textBoxSerialNumber
            // 
            this.textBoxSerialNumber.Location = new System.Drawing.Point(279, 3);
            this.textBoxSerialNumber.Multiline = true;
            this.textBoxSerialNumber.Name = "textBoxSerialNumber";
            this.textBoxSerialNumber.Size = new System.Drawing.Size(185, 39);
            this.textBoxSerialNumber.TabIndex = 10;
            this.toolTipTextBoxSerialNumber.SetToolTip(this.textBoxSerialNumber, "Insert Serial Number of the Bike (Contains only digtis from 0 to 9)");
            this.textBoxSerialNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSerialNumber_KeyPress);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.labelMake);
            this.panel5.Controls.Add(this.textBoxMake);
            this.panel5.Location = new System.Drawing.Point(5, 70);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(499, 53);
            this.panel5.TabIndex = 58;
            // 
            // labelMake
            // 
            this.labelMake.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelMake.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMake.Location = new System.Drawing.Point(39, 11);
            this.labelMake.Name = "labelMake";
            this.labelMake.Size = new System.Drawing.Size(173, 39);
            this.labelMake.TabIndex = 1;
            this.labelMake.Text = "Factory:";
            this.labelMake.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTipLabelMake.SetToolTip(this.labelMake, "Name of the Factory producing the Bike");
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.buttonView);
            this.panel7.Controls.Add(this.labelColor);
            this.panel7.Controls.Add(this.comboBoxColor);
            this.panel7.Location = new System.Drawing.Point(5, 218);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(497, 99);
            this.panel7.TabIndex = 58;
            // 
            // buttonView
            // 
            this.buttonView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonView.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonView.Location = new System.Drawing.Point(348, 45);
            this.buttonView.Name = "buttonView";
            this.buttonView.Size = new System.Drawing.Size(116, 40);
            this.buttonView.TabIndex = 48;
            this.buttonView.Text = "VIEW";
            this.toolTipButton.SetToolTip(this.buttonView, "Click to Display the Image of Color Bike");
            this.buttonView.UseVisualStyleBackColor = false;
            this.buttonView.Click += new System.EventHandler(this.buttonView_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.labelInsurance);
            this.panel8.Controls.Add(this.textBoxInsurance);
            this.panel8.Location = new System.Drawing.Point(5, 325);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(497, 65);
            this.panel8.TabIndex = 58;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.labelMountainBikeStyle);
            this.panel4.Controls.Add(this.comboBoxMountainBikeStyle);
            this.panel4.Location = new System.Drawing.Point(525, 325);
            this.panel4.Name = "panel4";
            this.tableLayoutPanelInformation.SetRowSpan(this.panel4, 2);
            this.panel4.Size = new System.Drawing.Size(527, 152);
            this.panel4.TabIndex = 57;
            // 
            // mountainBikeToolStripMenuItem
            // 
            this.mountainBikeToolStripMenuItem.Name = "mountainBikeToolStripMenuItem";
            this.mountainBikeToolStripMenuItem.Size = new System.Drawing.Size(118, 24);
            this.mountainBikeToolStripMenuItem.Text = "Mountain Bike";
            this.mountainBikeToolStripMenuItem.ToolTipText = "Click to choose Mountain Bike";
            this.mountainBikeToolStripMenuItem.Click += new System.EventHandler(this.mountainBikeToolStripMenuItem_Click);
            // 
            // roadBikeToolStripMenuItem
            // 
            this.roadBikeToolStripMenuItem.Name = "roadBikeToolStripMenuItem";
            this.roadBikeToolStripMenuItem.Size = new System.Drawing.Size(90, 24);
            this.roadBikeToolStripMenuItem.Text = "Road Bike";
            this.roadBikeToolStripMenuItem.ToolTipText = "Click to choose Road Bike";
            this.roadBikeToolStripMenuItem.Click += new System.EventHandler(this.roadBikeToolStripMenuItem_Click);
            // 
            // menuStripBike
            // 
            this.menuStripBike.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStripBike.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.roadBikeToolStripMenuItem,
            this.mountainBikeToolStripMenuItem});
            this.menuStripBike.Location = new System.Drawing.Point(0, 0);
            this.menuStripBike.Name = "menuStripBike";
            this.menuStripBike.Size = new System.Drawing.Size(1924, 28);
            this.menuStripBike.TabIndex = 57;
            this.menuStripBike.Text = "menuStrip1";
            // 
            // labelInformation
            // 
            this.labelInformation.AutoSize = true;
            this.labelInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInformation.ForeColor = System.Drawing.Color.Red;
            this.labelInformation.Location = new System.Drawing.Point(31, 130);
            this.labelInformation.Name = "labelInformation";
            this.labelInformation.Size = new System.Drawing.Size(185, 29);
            this.labelInformation.TabIndex = 62;
            this.labelInformation.Text = "INFORMATION";
            this.toolTipLabel.SetToolTip(this.labelInformation, "All the Information of Bike");
            // 
            // labelObservation
            // 
            this.labelObservation.AutoSize = true;
            this.labelObservation.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelObservation.ForeColor = System.Drawing.Color.Red;
            this.labelObservation.Location = new System.Drawing.Point(1104, 130);
            this.labelObservation.Name = "labelObservation";
            this.labelObservation.Size = new System.Drawing.Size(193, 29);
            this.labelObservation.TabIndex = 61;
            this.labelObservation.Text = "OBSERVATION";
            this.toolTipLabel.SetToolTip(this.labelObservation, "All the View of Lists of The Bike");
            // 
            // labelTitleLogin
            // 
            this.labelTitleLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelTitleLogin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTitleLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleLogin.ForeColor = System.Drawing.Color.Red;
            this.labelTitleLogin.Location = new System.Drawing.Point(0, 28);
            this.labelTitleLogin.Name = "labelTitleLogin";
            this.labelTitleLogin.Size = new System.Drawing.Size(1933, 81);
            this.labelTitleLogin.TabIndex = 60;
            this.labelTitleLogin.Text = "Bike Factory Managament";
            this.labelTitleLogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelFeature
            // 
            this.labelFeature.AutoSize = true;
            this.labelFeature.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFeature.ForeColor = System.Drawing.Color.Red;
            this.labelFeature.Location = new System.Drawing.Point(31, 659);
            this.labelFeature.Name = "labelFeature";
            this.labelFeature.Size = new System.Drawing.Size(130, 29);
            this.labelFeature.TabIndex = 58;
            this.labelFeature.Text = "FEATURE";
            this.toolTipLabel.SetToolTip(this.labelFeature, "All Available Feature supports Users enthusiatically ");
            // 
            // labelCopyRight
            // 
            this.labelCopyRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCopyRight.Location = new System.Drawing.Point(1526, 943);
            this.labelCopyRight.Name = "labelCopyRight";
            this.labelCopyRight.Size = new System.Drawing.Size(372, 40);
            this.labelCopyRight.TabIndex = 65;
            this.labelCopyRight.Text = " ©AMAZOO.CO COPYRIGHT ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1034);
            this.Controls.Add(this.labelCopyRight);
            this.Controls.Add(this.labelFeature);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelFeature);
            this.Controls.Add(this.tableLayoutPanelInformation);
            this.Controls.Add(this.menuStripBike);
            this.Controls.Add(this.labelInformation);
            this.Controls.Add(this.labelObservation);
            this.Controls.Add(this.labelTitleLogin);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panelFeature.ResumeLayout(false);
            this.panelFeature.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.tableLayoutPanelInformation.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.menuStripBike.ResumeLayout(false);
            this.menuStripBike.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView listViewMountainBike;
        private System.Windows.Forms.ColumnHeader columnHeaderSerialNumberMB;
        private System.Windows.Forms.ColumnHeader columnHeaderModelMB;
        private System.Windows.Forms.ColumnHeader columnHeaderMakeMB;
        private System.Windows.Forms.ColumnHeader columnHeaderColorMB;
        private System.Windows.Forms.ColumnHeader columnHeaderSpeedMB;
        private System.Windows.Forms.ColumnHeader columnHeaderDateMB;
        private System.Windows.Forms.ColumnHeader columnHeaderHeightFromGround;
        private System.Windows.Forms.ColumnHeader columnHeaderSuspension;
        private System.Windows.Forms.ColumnHeader columnHeaderMountainBikeStyle;
        private System.Windows.Forms.ColumnHeader columnHeaderInsuranceMB;
        private System.Windows.Forms.ListView listViewRoadBike;
        private System.Windows.Forms.ColumnHeader columnHeaderSerialNumber;
        private System.Windows.Forms.ColumnHeader columnHeaderModel;
        private System.Windows.Forms.ColumnHeader columnHeaderMake;
        private System.Windows.Forms.ColumnHeader columnHeaderColor;
        private System.Windows.Forms.ColumnHeader columnHeaderSpeed;
        private System.Windows.Forms.ColumnHeader columnHeaderDate;
        private System.Windows.Forms.ColumnHeader columnHeaderInsurance;
        private System.Windows.Forms.ColumnHeader columnHeaderSeatHeight;
        private System.Windows.Forms.ColumnHeader columnHeaderRoadBikeStyle;
        private System.Windows.Forms.Label labelListBoxRoadBike;
        private System.Windows.Forms.ListBox listBoxBike;
        private System.Windows.Forms.Label labelListBoxMountainBike;
        private System.Windows.Forms.Label labelListBoxBike;
        private System.Windows.Forms.ToolTip toolTipLabelMountainBikeStyle;
        private System.Windows.Forms.Label labelMountainBikeStyle;
        private System.Windows.Forms.ToolTip toolTipComboBoxRoadBikeStyle;
        private System.Windows.Forms.ComboBox comboBoxRoadBikeStyle;
        private System.Windows.Forms.ToolTip toolTipLabelRoadBikeStyle;
        private System.Windows.Forms.Label labelRoadBikeStyle;
        private System.Windows.Forms.ToolTip toolTipTextBoxHeightFromGround;
        private System.Windows.Forms.TextBox textBoxHeightFromGround;
        private System.Windows.Forms.ToolTip toolTipLabelHeightFromGround;
        private System.Windows.Forms.Label labelHeightFromGround;
        private System.Windows.Forms.ToolTip toolTipTextBoxSeatHeight;
        private System.Windows.Forms.TextBox textBoxSeatHeight;
        private System.Windows.Forms.ToolTip toolTipComboBoxSuspension;
        private System.Windows.Forms.ComboBox comboBoxSuspension;
        private System.Windows.Forms.ToolTip toolTipLabelSeatHeight;
        private System.Windows.Forms.Label labelSeatHeight;
        private System.Windows.Forms.ToolTip toolTipLabelSuspension;
        private System.Windows.Forms.Label labelSuspension;
        private System.Windows.Forms.ToolTip toolTipTextBoxSpeedUp;
        private System.Windows.Forms.TextBox textBoxSpeedUp;
        private System.Windows.Forms.ToolTip toolTipComboBoxMountainBikeStyle;
        private System.Windows.Forms.ComboBox comboBoxMountainBikeStyle;
        private System.Windows.Forms.ToolTip toolTipLabelSpeedUp;
        private System.Windows.Forms.Label labelSpeedUp;
        private System.Windows.Forms.ToolTip toolTipLabelSpeed;
        private System.Windows.Forms.Label labelSpeed;
        private System.Windows.Forms.ToolTip toolTipDateTimePicker;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.ToolTip toolTipTextBoxInsurance;
        private System.Windows.Forms.TextBox textBoxInsurance;
        private System.Windows.Forms.ToolTip toolTipLabelInsurance;
        private System.Windows.Forms.Label labelInsurance;
        private System.Windows.Forms.ToolTip toolTipComboBoxColor;
        private System.Windows.Forms.ComboBox comboBoxColor;
        private System.Windows.Forms.ToolTip toolTipLabelColor;
        private System.Windows.Forms.Label labelColor;
        private System.Windows.Forms.ToolTip toolTipLabelModel;
        private System.Windows.Forms.Label labelModel;
        private System.Windows.Forms.TextBox textBoxModel;
        private System.Windows.Forms.ToolTip toolTipTextBoxMake;
        private System.Windows.Forms.TextBox textBoxMake;
        private System.Windows.Forms.Label labelSearch;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.ToolTip toolTipTextBoxSpeed;
        private System.Windows.Forms.TextBox textBoxSpeed;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panelFeature;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.ToolTip toolTipButton;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.Button buttonDisplay;
        private System.Windows.Forms.ComboBox comboBoxTypeBike;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.ComboBox comboBoxReset;
        private System.Windows.Forms.Button buttonRemove;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.ComboBox comboBoxClear;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Button buttonSpeedUp;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.ToolTip toolTipLabelDate;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelInformation;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelSerialNumber;
        private System.Windows.Forms.ToolTip toolTipLabelSerialNumber;
        private System.Windows.Forms.TextBox textBoxSerialNumber;
        private System.Windows.Forms.ToolTip toolTipTextBoxSerialNumber;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label labelMake;
        private System.Windows.Forms.ToolTip toolTipLabelMake;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button buttonView;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ToolStripMenuItem mountainBikeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roadBikeToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStripBike;
        private System.Windows.Forms.Label labelInformation;
        private System.Windows.Forms.Label labelObservation;
        private System.Windows.Forms.Label labelTitleLogin;
        private System.Windows.Forms.Label labelFeature;
        private System.Windows.Forms.ToolTip toolTipSearch;
        private System.Windows.Forms.ToolTip toolTipComboBoxOption;
        private System.Windows.Forms.ToolTip toolTipLabel;
        private System.Windows.Forms.ToolTip toolTipList;
        private System.Windows.Forms.Label labelCopyRight;
    }
}

