﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public enum EnumBikeType
    {
        Road_Bike,
        Mountain_Bike,
        All_Bike,
        Undefined
    }
}
