﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bike_Factory.bus;

namespace Bike_Factory.client
{

    public partial class Register : Form
    {
        public delegate void MyDelegate(List<Account> list);
        public MyDelegate linkList;
            List<Account> listOfAccountRegister = new List<Account>();
        public Register()
        {
            InitializeComponent();
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            string currentUserName, currentPassword;
            Account currentAccount = null;
            bool checkUserName = true;
            foreach (Account checkDuplicate in listOfAccountRegister)
            {
                if (checkDuplicate.Username==this.textBoxUserNameRegister.Text)
                {
                    checkUserName=false;
                }
            }
            
            if (this.textBoxUserNameRegister.Text.Length > 0)
            {
                if (checkUserName)
                {
                    if (this.textBoxPasswordRegister.Text.Length > 0)
                    {

                        if (this.textBoxReenterPasswordRegister.Text == this.textBoxPasswordRegister.Text)
                        {
                            currentUserName = this.textBoxUserNameRegister.Text;
                            currentPassword = this.textBoxPasswordRegister.Text;
                            currentAccount = new Account(currentUserName, currentPassword);
                            listOfAccountRegister.Add(currentAccount);
                            MessageBox.Show($"Register Successfully\n\nThe information of your User:\n{currentAccount}", "Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        }
                        else
                        {
                            MessageBox.Show("Your Password isn't matched with the Re-enter Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Can not create an user without Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("There already exisit this User Name please choose another one", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }

            }
            else
            {
                MessageBox.Show("Can not create an user without User Name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void buttonBackToLogin_Click(object sender, EventArgs e)
        {
            linkList(listOfAccountRegister);
            this.Close();
            
        }
    }
}
