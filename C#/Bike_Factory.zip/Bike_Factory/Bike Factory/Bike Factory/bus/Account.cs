﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bike_Factory.client;

namespace Bike_Factory.bus
{
    [Serializable]
    public class Account
    {
        private string username;
        private string password;

        public string Username
        {
            get { return this.username; }
            set { this.username = value; }
        }
        public string Password
        {
            get { return this.password; }
            set { this.password = value; }
        }

        public Account()
        {
            this.Username = "Undefined";
            this.Password = "Undefined";
        }
        public Account(string username, string password)
        {
            this.Username = username;
            this.Password = password;
        }

        public override string ToString()
        {
            return $"User name: {this.Username}\nPassword: {this.Password}";
        }
    }
}
