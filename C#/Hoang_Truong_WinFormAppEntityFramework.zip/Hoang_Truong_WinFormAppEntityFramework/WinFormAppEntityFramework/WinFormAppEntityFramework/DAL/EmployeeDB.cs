﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormAppEntityFramework.Model;
namespace WinFormAppEntityFramework.DAL
{
    public static class EmployeeDB
    {

        public static List<Employee> GetAllRecords()
        {
            List<Employee> listE = new List<Employee>();
            using (EmployeeProjectDBEntities db = new EmployeeProjectDBEntities())
            {
                var listItem = (from employee in db.Employees
                             select employee);
                Employee emp;
                foreach (var item in listItem)
                {
                    emp = new Employee();
                    emp.EmployeeId = item.EmployeeId;
                    emp.FirstName = item.FirstName;
                    emp.PhoneNumber = item.PhoneNumber;
                    emp.LastName = item.LastName;
                    emp.Email = item.Email;
                    listE.Add(emp);
                }
            }

            
            return listE;
        }
    }
}
