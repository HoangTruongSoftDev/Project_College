﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace WinFormAppEntityFramework.VALIDATION
{
    public static class Validator
    {
        public static bool IsCorrectFormatEmpID(string input, int size)
        {
            if (Regex.IsMatch(input,@"^\d{"+ size +"}$"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsCorrectFormatPhoneNumber(string input)
        {
            if (Regex.IsMatch(input,@"^\(\d{3}\)\d{3}\-\d{4}$"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
