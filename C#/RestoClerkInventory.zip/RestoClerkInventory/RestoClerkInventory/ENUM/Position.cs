﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestoClerkInventory.ENUM
{
    public enum Position
    {
        Admin,
        Manager,
        Staff,
        Undefined
    }
}