--1) Write a query to display the total number of objects and the object type from the database schema
SELECT COUNT (OBJECT_NAME) AS TOTAL_OBJECTS,OBJECT_TYPE FROM USER_OBJECTS GROUP BY OBJECT_TYPE ORDER BY OBJECT_TYPE ASC;

--OUTPUT
--TOTAL_OBJECTS OBJECT_TYPE
--------------- -------------------
--           19 INDEX
--            4 SEQUENCE
--           10 TABLE


-- Then, write a query to display the list of 10 tables from the database schema with the following formatting:
SELECT TABLE_NAME FROM USER_TABLES ORDER BY TABLE_NAME ASC;

--OUTPUT


--TABLE_NAME
--------------------------------
--COURSE
--ENROLLMENT
--GRADE
--GRADE_CONVERSION
--GRADE_TYPE
--GRADE_TYPE_WEIGHT
--INSTRUCTOR
--SECTION
--STUDENT
--ZIPCODE

--10 rows selected.
GO


--2) Write a query to display the FIRST_NAME and LAST_NAME of all instructors who are living in the city of New York. Hint: use a join between Instructor and Zipcode tables

SELECT i.FIRST_NAME, i.LAST_NAME FROM INSTRUCTOR i JOIN ZIPCODE z ON i.ZIP = z.ZIP WHERE z.CITY = 'New York';


--OUTPUT


--FIRST_NAME                LAST_NAME
--------------------------- -------------------------
--03ilyn                    Frantzen
--Fernand                   Hanks
--Anita                     Morris
--Rick                      Chow
--Tom                       Wojick
--Nina                      Schorin
--Todd                      Smythe
--Charles                   Lowry
--Gary                      Pertez

--9 rows selected.




--3) Write a query to display the FIRST_NAME, LAST_NAME, STREET_ADDRESS, CITY and STATE of all students who live in Manchester (MA) and Ohio(OH). Hint: use a join between Student and Zipcode tables.

SELECT s.FIRST_NAME, s.LAST_NAME, s.STREET_ADDRESS, z.CITY, z.STATE FROM STUDENT s JOIN ZIPCODE z ON s.ZIP = z.ZIP WHERE z.STATE IN ('MA','OH') ORDER BY z.STATE;


--OUTPUT
--FIRST_NAME                LAST_NAME
--------------------------- -------------------------
--STREET_ADDRESS                                     CITY                      ST
---------------------------------------------------- ------------------------- --
--Judy                      Sethi
--Stratton Hall                                      Tufts Univ. Bedford       MA

--James E.                  Norman
--PO Box 809 Curran Hwy                              North Adams               MA

--Thomas E.                 La Blank
--49 Raleigh Rd                                      Weymouth                  MA


--FIRST_NAME                LAST_NAME
--------------------------- -------------------------
--STREET_ADDRESS                                     CITY                      ST
---------------------------------------------------- ------------------------- --
--George                    Kocka
--24 Beaufield St.                                   Dorchester                MA

--Walter                    Boremmann
--88 Old Fields Rd                                   Sandwich                  MA

--Phil                      Gilloon
--4244 Morestown Ct. E                               Columbus                  OH


--6 rows selected.




--4) Write a query to display the location, and the highest and lowest capacity for each location. Hint: use SQL function and table SECTION.
SELECT LOCATION, MIN(CAPACITY), MAX(CAPACITY) FROM SECTION GROUP BY LOCATION;

--OUTPUT
--LOCATION                                           MIN(CAPACITY) MAX(CAPACITY)
---------------------------------------------------- ------------- -------------
--H310                                                          15            15
--L214                                                          15            25
--L210                                                          15            25
--M500                                                          25            25
--M311                                                          25            25
--L507                                                          15            25
--L206                                                          15            15
--L500                                                          12            15
--L511                                                          25            25
--M200                                                          15            15
--L509                                                          10            25

--LOCATION                                           MIN(CAPACITY) MAX(CAPACITY)
---------------------------------------------------- ------------- -------------
--L211                                                          15            25

--12 rows selected.



--5) Write a query to display the STUDENT_ID and FINAL_GRADE of students having the highest FINAL_GRADE (of all SECTIONS). Hint: use a subquery that returns the maximum FINAL_GRADE of the ENROLLMENT table.
SELECT STUDENT_ID, FINAL_GRADE FROM ENROLLMENT WHERE FINAL_GRADE = (SELECT MAX(FINAL_GRADE) FROM ENROLLMENT);


--OUTPUT
--STUDENT_ID FINAL_GRADE
------------ -----------
--       102          92


--6) Write a query to display COURSE_NO, DESCRIPTION, COST, and PREREQUISITE of all courses that have a minimum cost Hint: use a subquery that returns the minimum cost of the COURSE table
 SELECT COURSE_NO, DESCRIPTION, COST, PREREQUISITE FROM COURSE WHERE COST = (SELECT MIN(COST) FROM COURSE);


 --OUTPUT
--  COURSE_NO DESCRIPTION                                              COST		PREREQUISITE
------------ -------------------------------------------------- ----------	  --------------
--       135 Unix Tips and Techniques                                 1095				134

--       230 Intro to the Internet                                    1095				 10

--       240 Intro to the BASIC Language                              1095				 25



