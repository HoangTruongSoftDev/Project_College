--Group member: Tuan Hung Bui, Vinh Quang Nguyen, Brian, Hoang Truong Pham
--Owner'script name: Hoang Truong Pham
--StudentID: 202130169
--CourseID: 420-BD1-AS C2_DATABASES I_420BP
--Professor: Houria Houmel

--Project Database: descartesdb
-- Part 2 MICROSOFT SQL SERVER
--Taks:
--Using TRANSACT_SQL:
--1- Create database schema
--2- Alter database schema
--3- Enforce data consistency (data integrity)
--4- Populate the tables: 15 rows per table


--1) Create the database schema.

--1.1) Use MASTER database, then create the database descartesdb
-- Use MASTER database: The Master database is the primary configuration database in SQL Server, use it to be able to access information on all the databases that exist on the server
USE master
GO

--create the database descartesdb if there's already had database named descartesdb, drop it to create that database again.However, create that database if it doesn't exist.
IF EXISTS (SELECT * FROM sysdatabases WHERE name='descartesdb')
DROP DATABASE descartesdb;

EXEC ('CREATE DATABASE descartesdb');
GO

--1.2) Create primary and associative tables

--USE descartesdb means access information of the database named descartesdb
USE descartesdb
GO
--1.2.a) Create primary tables
--Create table dbo.Student with 7 NULL columns named Student_id, Student_first_name, Student_last_name, Student_gender, Student_social_security_number, Student_nationality and Student_age
CREATE TABLE dbo.Student
(
	Student_id INT NULL,
	Student_first_name NVARCHAR(50) NULL,
	Student_last_name  NVARCHAR(50) NULL,
	Student_gender NVARCHAR(50) NULL,
	Student_social_security_number NVARCHAR(11) NULL,
	Student_nationality NVARCHAR(50) NULL,
	Student_age INT NULL
)

--Create table sbo.Course with 8 NULL columns and 1 computed columns which are Course_id, Course_title, Hour_number, Credits, Fee_per_credit, Prerequisite, Outdoor_activities, Required_document and Course_fee
CREATE TABLE dbo.Course
(
	Course_id INT NULL,	
	Course_title NVARCHAR(50) NULL,
	Hour_number INT NULL,
	Credits INT NULL,
	Fee_per_credit FLOAT NULL,
	Prerequisite NVARCHAR(50) NULL,
	Outdoor_activities NVARCHAR(50) NULL,
	Required_document NVARCHAR(50) NULL,
	Course_fee AS (Credits*Fee_per_credit)
)

 

--Create table dbo.Teacher with 10 NULL columns named Teacher_id, Teacher_first_name, Teacher_last_name, Teacher_gender, Teacher_grade, Year_of_education, Teacher_social_security_number, Department_id, Teacher_nationality and Teacher_age 
CREATE TABLE dbo.Teacher
(
	Teacher_id INT NULL,
	Teacher_first_name NVARCHAR(50) NULL,
	Teacher_last_name NVARCHAR(50) NULL,
	Teacher_gender NVARCHAR(50) NULL,
	Teacher_grade NVARCHAR(50) NULL,
	Year_of_education INT NULL,
	Teacher_social_security_number NVARCHAR(11) NULL,
	Department_id INT NULL,
	Teacher_nationality NVARCHAR(50) NULL,
	Teacher_age INT NULL
)

--Create table dbo.Department with 2 NULL columns named Department_id and Department_name
CREATE TABLE dbo.Department
(
	Department_id INT NULL,
	Department_name NVARCHAR(50) NULL
)
 
--1.2.b) Create associative tables

--Create table dbo.Student_Course with 5 NULL columns named Student_id, Course_id, Registration_number, Registration_date and Course_fee 
CREATE TABLE dbo.Student_Course
(
	Student_id INT NULL,
	Course_id INT NULL,
	Registration_number NVARCHAR(50) NULL,
	Registration_date DATE NULL,
) 


--Create table dbo.Course_Teacher with 7 NULL columns and 1 computed column which are Course_id, Teacher_id, Teacher_contract_number, Hour_number_work, Hour_rate, Start_date, End_date and Salary 
CREATE TABLE dbo.Course_Teacher
(
	Course_id INT NULL,
	Teacher_id INT NULL,
	Teacher_contract_number NVARCHAR(50) NULL,
	Hour_number_work INT NULL,
	Hour_rate INT NULL,
	[Start_date] DATE NULL,
	End_date DATE NULL
)
ALTER TABLE Course_Teacher ADD Salary AS (Hour_number_work*Hour_rate);
GO

--1.3) Create an index on the department name column
CREATE INDEX IDX_Department_name ON dbo.Department(Department_name);
GO

--1.4) Create a SEQUENCE named SEQ_Number starting with 1 and incremented by 1, then use this SEQUENCE to populate the Department table.
--Create sequence for table Department named SEQ_Number starting with 1 and incremented by 1, the sequence will be used later in population which is the last section of part 2 
CREATE SEQUENCE SEQ_Number START WITH 1 INCREMENT BY 1;
GO

--2) Create the necessary constraints to ensure data consistency (data integrity)

--2.1) 

	--1. Not Null constraint (department name must be not null).

ALTER TABLE dbo.Student ALTER COLUMN Student_id INT NOT NULL;				--alter column named Student_id of table dbo.Student as NOT NULL
ALTER TABLE dbo.Student_Course ALTER COLUMN Student_id INT NOT NULL;		--alter column named Student_id of table dbo.Student_Course as NOT NULL
ALTER TABLE dbo.Student_Course ALTER COLUMN Course_id INT NOT NULL;			--alter column named Course_id of table dbo.Student_Course as NOT NULL
ALTER TABLE dbo.Course ALTER COLUMN Course_id INT NOT NULL;					--alter column named Course_id of table dbo.Course as NOT NULL
ALTER TABLE dbo.Course_Teacher ALTER COLUMN Course_id INT NOT NULL;			--alter column named Course_id of table dbo.Course_Teacher as NOT NULL
ALTER TABLE dbo.Course_Teacher ALTER COLUMN Teacher_id INT NOT NULL;		--alter column named Teacher_id of table dbo.Course_Teacher as NOT NULL
ALTER TABLE dbo.Teacher ALTER COLUMN Teacher_id INT NOT NULL;				--alter column named Teacher_id of table dbo.Teacher as NOT NULL
ALTER TABLE dbo.Department ALTER COLUMN Department_id INT NOT NULL;			--alter column named Department_id of table dbo.Department as NOT NULL

--Modifying NOT NULL or NULL for column have index need to be execute before adding index
DROP INDEX  dbo.Department.IDX_Department_name;										
ALTER TABLE dbo.Department ALTER COLUMN Department_name NVARCHAR(50) NOT NULL; --alter column named Department_name of table dbo.Department as NOT NULL
CREATE INDEX IDX_Department_name ON dbo.Department(Department_name);			--Create an index named IDX_Department_name on the Department_name column of table dbo.Department
GO
	--2. Unique constraint named UQ_SSN (social security number must be unique)
ALTER TABLE dbo.Teacher ADD CONSTRAINT UQ_SSN UNIQUE (Teacher_social_security_number);			--add constraint Unique named UQ_SSN for column named Teacher_social_security_number of table dbo.Teacher
ALTER TABLE dbo.Student ADD CONSTRAINT UQ_SSN_Student UNIQUE(Student_social_security_number);	--add constraint Unique named UQ_SSN_Student for column named Student_social_security_number of table dbo.Student
GO

	--3. Default constraint named DF_XXX (your choice, where XXX is the column name)
ALTER TABLE dbo.Course ADD CONSTRAINT DF_Fee_per_credit DEFAULT 175 FOR Fee_per_credit;			--add constraint Default named DF_fee_per_credit for column named Fee_per_credit of table dbo.Course with the default value is 175
GO
	--4. Check constraint named CK_YYY (your choice, where YYY is the column name)
ALTER TABLE dbo.Teacher ADD CONSTRAINT CK_Teacher_age CHECK (Teacher_age>=24);										--add constraint Check named CK_Teacher_age with condition is that the value of column named Teacher_age of table dbo.Teacher higher or equal than 24
ALTER TABLE dbo.Student ADD CONSTRAINT CK_Student_gender CHECK (Student_gender='Male' OR Student_gender='Female');	--add constraint Check named CK_Student_gender with condition is that the value of column named Student_gender of table dbo.Student is Male or Female
GO

--2.2) Entity integrity
ALTER TABLE dbo.Student ADD CONSTRAINT PK_Student PRIMARY KEY CLUSTERED (Student_id);								--add constraint Primary Key named PK_Student for column named Student_id of table named dbo.Student
ALTER TABLE dbo.Student_Course ADD CONSTRAINT PK_Student_Course PRIMARY KEY CLUSTERED (Student_id, Course_id);		--add constraint Primary Key named PK_Student_Course for two columns named Student_id and Course_id of table named dbo.Student_Course
ALTER TABLE dbo.Course ADD CONSTRAINT PK_Course PRIMARY KEY CLUSTERED (Course_id);									--add constraint Primary Key named PK_Course for column named Course_id of table named dbo.Course
ALTER TABLE dbo.Course_Teacher ADD CONSTRAINT PK_Course_Teacher PRIMARY KEY CLUSTERED (Course_id, Teacher_id);		--add constraint Primary Key named PK_Course_Teacher for two columns named Course_id and Teacher_id of table named dbo.Course_Teacher
ALTER TABLE dbo.Teacher ADD CONSTRAINT PK_Teacher PRIMARY KEY CLUSTERED (Teacher_id);								--add constraint Primary Key named PK_Teacher for column named Teacher_id of table named dbo.Teacher
ALTER TABLE dbo. Department ADD CONSTRAINT PK_Department PRIMARY KEY CLUSTERED (Department_id);						--add constraint Primary Key named PK_Department for column named Department_id of table named dbo.Department
GO
--2.3) Referential integrity and Self-referential integrity
ALTER TABLE dbo.Student_Course ADD CONSTRAINT FK_Student_Course_Student FOREIGN KEY (Student_id) REFERENCES dbo.Student(Student_id);	--add constraint Foreign Key named FK_Student_Course_Student for column named Student_id of table named dbo.Student_Course refer to column Student_id of table dbo.Student
ALTER TABLE dbo.Student_Course ADD CONSTRAINT FK_Student_Course_Course FOREIGN KEY (Course_id) REFERENCES dbo.Course(Course_id);		--add constraint Foreign Key named FK_Student_Course_Course for column named Course_id of table named dbo.Student_Course refer to column Course_id of table dbo.Course
ALTER TABLE dbo.Course_Teacher ADD CONSTRAINT FK_Course_Teacher_Course FOREIGN KEY (Course_id) REFERENCES dbo.Course(Course_id);		--add constraint Foreign Key named FK_Course_Teacher_Course for column named Course_id of table named dbo.Course_Teacher refer to column Course_id of table dbo.Course
ALTER TABLE dbo.Course_Teacher ADD CONSTRAINT FK_Course_Teacher_Teacher FOREIGN KEY (Teacher_id) REFERENCES dbo.Teacher(Teacher_id);	--add constraint Foreign Key named FK_Course_Teacher_Teacher for column named Teacher_id of table named dbo.Course_Teacher refer to column Teacher_id of table dbo.Teacher
ALTER TABLE dbo.Teacher ADD CONSTRAINT FK_Teacher_Department FOREIGN KEY (Department_id) REFERENCES dbo.Department(Department_id);		--add constraint Foreign Key named FK_Teacher_Department for column named Department_id of table named dbo.Teacher refer to column Department_id of table dbo.Department
GO

--3) Populate the tables

--Populate table dbo.Student
--Insert data into table dbo.Student with the format VALUES(Student_id, Student_first_name, Student_last_name, Student_gender, Student_social_security_number, Student_nationality, Student_age)
INSERT INTO dbo.Student VALUES (1,'Truong','Pham','Male','111-222-111', 'Vietnamese', 19);
INSERT INTO dbo.Student VALUES (2,'Thien','Nguyen','Male','111-222-222', 'Vietnamese', 19);
INSERT INTO dbo.Student VALUES (3,'Hung','Bui','Male','111-222-333', 'Vietnamese', 19);
INSERT INTO dbo.Student VALUES (4,'Khoa','Nguyen','Male','111-222-444', 'Vietnamese', 19);
INSERT INTO dbo.Student VALUES (5,'Quang','Nguyen','Male','111-222-555', 'Vietnamese', 19);
INSERT INTO dbo.Student VALUES (6,'Kiet','Nguyen','Male','111-222-666', 'Vietnamese', 20);
INSERT INTO dbo.Student VALUES (7,'Dat','Nguyen','Male','111-222-777', 'Vietnamese', 21);
INSERT INTO dbo.Student VALUES (8,'Duy','Vu','Male','111-222-888', 'Vietnamese', 19);
INSERT INTO dbo.Student VALUES (9,'Michelle','Williams','Female','111-222-999', 'British', 18);
INSERT INTO dbo.Student VALUES (10,'Justin','Bieber','Male','111-333-111', 'American', 23);
INSERT INTO dbo.Student VALUES (11,'Oriana','Pham','Female','111-333-222', 'Canadian', 19);
INSERT INTO dbo.Student VALUES (12,'Thresh','Alex','Male','111-333-333', 'Brazil', 19);
INSERT INTO dbo.Student VALUES (13,'Fiora','James','Female','111-333-444', 'Indian', 21);
INSERT INTO dbo.Student VALUES (14,'Leona','Nguyen','Female','111-333-555', 'British', 20);
INSERT INTO dbo.Student VALUES (15,'Yuumi','Depp','Female','111-333-666', 'Italian', 21);
GO
--Populate table dbo.Course
--Insert data into table dbo.Course with the format VALUES(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document)
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(1,'Database',50,4,'None', 'None', 'Learning Database');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(2,'OOP',55,4,'Finished Algorithm', 'None', 'Learning C##');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(3,'Algorithm',40,1,'None', 'Museum Science', 'Pseudo Code document');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(4,'PE',35,3,'None', 'Atwater metro', 'Healthy excercise');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(5,'Installation and Config',50,5,'None', 'McGill University', 'Linux_Command');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(6,'Immersion English',60,5,'None', 'McCord Museum', 'Grammar documents');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(7,'Web development',45,3,'Finished Intro Web', 'None', 'Syntax HTMl/CSS_advanced');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(8,'Intro Web',50,4,'None', 'None', 'syntax HTML/CSS');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(9,'Remedial English',40,3,'Finished Immersion', 'None', 'Analysis document');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(10,'French Beginner',30,3,'None', 'Old Port', 'French vocabulary');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(11,'French Intermidiate',35,5,'Finished Beginner', 'None', 'French_grammar');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(12,'Collegial Life',34,5,'None', 'None', 'Online document');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(13,'Operating System',30,3,'None', 'None', 'Window System');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(14,'Computer Architecture',35,5,'None', 'Biodome', 'Hardware List');
INSERT INTO dbo.Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(15,'Applied Math',34,5,'None', 'None', 'Math documents');
GO

--Populate table Department
--Insert data into table dbo.Department with the format VALUES(Department_id, Department_name)
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Computer Science');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Mathematics');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Sport indsutry');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'English literature');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Agriculture');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Environment');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Finance');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Statistics');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Medical');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Tourism');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Hotel Management');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Science');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Designer');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Economics');
INSERT INTO dbo.Department VALUES (NEXT VALUE FOR SEQ_Number,'Logistics');
GO

--Populate table dbo.Teacher
--Insert data into table dbo.Teacher with the format VALUES(Teacher_id, Teacher_first_name, Teacher_last_name, Teacher_gender, Teacher_grade, Year_of_education, Teacher_social_security_number, Department_id, Teacher_nationality, Teacher_age)
INSERT INTO dbo.Teacher VALUES (1,'Ahri','Akali', 'Female', 'PhD', 21, '111-333-777', 1, 'Chinese', 30);
INSERT INTO dbo.Teacher VALUES (2,'Braum','Ashan', 'Male', 'Master', 22, '111-333-888', 1, 'Russian', 26);
INSERT INTO dbo.Teacher VALUES (3,'Caitlyn','Vi', 'Female', 'Bachelor', 24, '111-333-999', 1, 'French', 31);
INSERT INTO dbo.Teacher VALUES (4,'An','Wong', 'Male', 'Master', 25, '111-444-111', 2, 'Chinese', 55);
INSERT INTO dbo.Teacher VALUES (5,'Camille','Jay', 'Female', 'PhD', 21, '111-444-222', 2, 'American', 30);
INSERT INTO dbo.Teacher VALUES (6,'Mundo','Draven', 'Male', 'Master', 22, '111-444-333', 2, 'Bristish', 26);
INSERT INTO dbo.Teacher VALUES (7,'Ezreal','Pham', 'Male', 'Bachelor', 24, '111-444-444', 3, 'Vietnamese', 35);
INSERT INTO dbo.Teacher VALUES (8,'Sylvain','Desmarteau', 'Male', 'Master', 25, '111-444-555', 3, 'Russian', 55);
INSERT INTO dbo.Teacher VALUES (9,'Janna','Ivern', 'Female', 'PhD', 21, '111-444-666', 3, 'Italian', 30);
INSERT INTO dbo.Teacher VALUES (10,'Jarvan','Jhin', 'Male', 'Master', 22, '111-444-777', 4, 'Russian', 26);
INSERT INTO dbo.Teacher VALUES (11,'Jinx','Kalista', 'Female', 'Bachelor', 24, '111-444-888', 5, 'French', 31);
INSERT INTO dbo.Teacher VALUES (12,'Karma','Kayn', 'Female', 'Master', 25, '111-444-999', 6, 'Chinese', 55);
INSERT INTO dbo.Teacher VALUES (13,'Lee Sin','Leblanc', 'Male', 'PhD', 21, '111-555-111', 7, 'American', 30);
INSERT INTO dbo.Teacher VALUES (14,'Maokai','Darius', 'Male', 'Master', 22, '111-555-222', 8, 'Bristish', 26);
INSERT INTO dbo.Teacher VALUES (15,'Nidalee','Neeko', 'Female', 'Bachelor', 24, '111-555-333', 3, 'Vietnamese', 35);
GO

--Populate table dbo.Student_Course
--Insert data into table dbo.Student_Course with the format VALUES(student_id, course_id, registration_number, registration_date)
INSERT INTO dbo.Student_Course VALUES(1,1,'202130169','2022-05-03');
INSERT INTO dbo.Student_Course VALUES(1,3,'584544544','2022-01-09');
INSERT INTO dbo.Student_Course VALUES(1,2,'202130169','2022-05-03');
INSERT INTO dbo.Student_Course VALUES(2,5,'202012343','2021-08-08');
INSERT INTO dbo.Student_Course VALUES(3,4,'202123232','2022-05-03');
INSERT INTO dbo.Student_Course VALUES(3,6,'202123232','2022-05-03');
INSERT INTO dbo.Student_Course VALUES(1,5,'483439343','2021-08-08');
INSERT INTO dbo.Student_Course VALUES(1,9,'584544544','2022-01-09');
INSERT INTO dbo.Student_Course VALUES(1,10,'584544544','2022-01-09');
INSERT INTO dbo.Student_Course VALUES(1,11,'202130169','2022-05-03');
INSERT INTO dbo.Student_Course VALUES(6,8,'202343334','2022-01-09');
INSERT INTO dbo.Student_Course VALUES(1,7,'202130169','2022-05-03');
INSERT INTO dbo.Student_Course VALUES(10,13,'323455434','2022-05-03');
INSERT INTO dbo.Student_Course VALUES(9,15,'283907896','2022-01-09');
INSERT INTO dbo.Student_Course VALUES(7,14,'386798767','2022-01-09');
GO

--Populate table dbo.Course_Teacher
--Insert data into table dbo.Course_Teacher with the format VALUES(course_id, teacher_id, teacher_contract_number, hour_number_work, hour_rate, start_date, end_date, salary)
INSERT INTO dbo.Course_Teacher VALUES(1,1,'202102348',50,30,'2022-05-10','2022-07-30');
INSERT INTO dbo.Course_Teacher VALUES(2,1,'202102348',55,34,'2022-05-10','2022-07-30');
INSERT INTO dbo.Course_Teacher VALUES(3,3,'230239790',40,33,'2022-01-11','2022-05-01');
INSERT INTO dbo.Course_Teacher VALUES(2,3,'839433433',55,34,'2022-05-10','2022-07-30');
INSERT INTO dbo.Course_Teacher VALUES(2,2,'903834343',55,34,'2022-05-10','2022-07-30');
INSERT INTO dbo.Course_Teacher VALUES(3,2,'794349343',40,33,'2022-01-11','2022-05-01');
INSERT INTO dbo.Course_Teacher VALUES(1,2,'903834343',50,30,'2022-05-10','2022-07-30');
INSERT INTO dbo.Course_Teacher VALUES(5,1,'683901620',50,32,'2021-08-10','2021-12-30');
INSERT INTO dbo.Course_Teacher VALUES(14,3,'578901231',35,31,'2022-01-11','2022-05-01');
INSERT INTO dbo.Course_Teacher VALUES(15,4,'349013675',34,32,'2022-01-11','2022-05-01');
INSERT INTO dbo.Course_Teacher VALUES(15,6,'987394343',34,32,'2022-01-11','2022-05-01');
INSERT INTO dbo.Course_Teacher VALUES(6,10,'242399434',60,30,'2021-08-10','2021-12-30');
INSERT INTO dbo.Course_Teacher VALUES(9,10,'893434976',40,32,'2022-01-11','2022-05-01');
INSERT INTO dbo.Course_Teacher VALUES(4,7,'128329856',35,33,'2022-01-11','2022-05-01');
INSERT INTO dbo.Course_Teacher VALUES(4,8,'609182323',35,33,'2022-01-11','2022-05-01');
GO
