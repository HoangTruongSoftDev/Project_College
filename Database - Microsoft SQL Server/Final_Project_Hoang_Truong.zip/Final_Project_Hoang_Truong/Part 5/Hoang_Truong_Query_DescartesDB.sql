--1) Display Teacher first name as Teacher Name, number contract of teacher, and the salary if that teacher has the highest salary

SELECT (t.Teacher_first_name) as Teacher_Name, ct.Teacher_contract_number,ct.salary FROM Teacher t JOIN Course_Teacher ct ON t.Teacher_id = ct.Teacher_id WHERE ct.Salary =(SELECT MAX(Salary) FROM Course_Teacher);

--Output
--TEACHER_NAME
----------------------------------------------------
--TEACHER_CONTRACT_NUMBER                                SALARY
---------------------------------------------------- ----------
--Ahri
--202102348                                                1870

--Caitlyn
--839433433                                                1870

--Braum
--903834343                                                1870

--2) Display the total number of student who is 19 years old
SELECT COUNT(Student_Age) as Total_student_of_19_years_old FROM Student WHERE Student_age=19;

--output
--TOTAL_STUDENT_OF_19_YEARS_OLD
-------------------------------
--                            8


--3) display the list of tables from the database
SELECT TABLE_NAME FROM USER_TABLES ORDER BY TABLE_NAME ASC;

--output
--TABLE_NAME
--------------------------------
--COURSE
--COURSE_TEACHER
--DEPARTMENT
--STUDENT
--STUDENT_COURSE
--TEACHER

--6 rows selected.

--4) Display the total number of objects and the object type from the database schema
SELECT COUNT (OBJECT_NAME) AS TOTAL_OBJECTS,OBJECT_TYPE FROM USER_OBJECTS GROUP BY OBJECT_TYPE ORDER BY OBJECT_TYPE ASC;


--output
--TOTAL_OBJECTS OBJECT_TYPE
--------------- -------------------
--            9 INDEX
--            1 SEQUENCE
--            6 TABLE


--5) Display the column and type of table Student
DESC Student

 --Name                                      Null?    Type
 ------------------------------------------- -------- ----------------------------
 --STUDENT_ID                                NOT NULL NUMBER(3)
 --STUDENT_FIRST_NAME                                 VARCHAR2(50)
 --STUDENT_LAST_NAME                                  VARCHAR2(50)
 --STUDENT_GENDER                                     VARCHAR2(6)
 --STUDENT_SOCIAL_SECURITY_NUMBER                     VARCHAR2(11)
 --STUDENT_NATIONALITY                                VARCHAR2(50)
 --STUDENT_AGE                                        NUMBER(3)

 --6) Display the the course Id and course title of table Course
 SELECT Course_id, Course_title From Course;

--output
--  COURSE_ID COURSE_TITLE
------------ --------------------------------------------------
--         1 Database
--         2 OOP
--         3 Algorithm
--         4 PE
--         5 Installation and Config
--         6 Immersion English
--         7 Web development
--         8 Intro Web
--         9 Remedial English
--        10 French Beginner
--        11 French Intermidiate

-- COURSE_ID COURSE_TITLE
------------ --------------------------------------------------
--        12 Collegial Life
--        13 Operating System
--        14 Computer Architecture
--        15 Applied Math

--15 rows selected.

--7) Display the teacher id, teacher first name and teacher age who has the age is 30
SELECT Teacher_id, Teacher_first_name, Teacher_age FROM Teacher WHERE Teacher_age = 30;

--output
--TEACHER_ID TEACHER_FIRST_NAME                                 TEACHER_AGE
------------ -------------------------------------------------- -----------
--         1 Ahri                                                        30
--         5 Camille                                                     30
--         9 Janna                                                       30
--        13 Lee Sin                                                     30
