


CONNECT / AS SYSDBA

DROP USER descartesdb CASCADE;
CREATE USER descartesdb IDENTIFIED BY 123;

GRANT CONNECT, RESOURCE TO descartesdb;

CONNECT descartesdb/123

CREATE SEQUENCE SEQ_Number START WITH 1 INCREMENT BY 1;
CREATE TABLE Student (Student_id NUMBER(3), Student_first_name VARCHAR2(50), Student_last_name VARCHAR2(50), Student_gender VARCHAR2(6), Student_social_security_number VARCHAR2(11), Student_nationality VARCHAR2(50), Student_age NUMBER(3));
CREATE TABLE Course(Course_id NUMBER(3), Course_title VARCHAR2(50), Hour_number NUMBER(3), Credits NUMBER(3), Fee_per_credit NUMBER(3), Prerequisite VARCHAR2(50), Outdoor_activities VARCHAR2(50), Required_document VARCHAR2(50), Course_fee as (Credits*Fee_per_credit));
CREATE TABLE Teacher(Teacher_id NUMBER(3), Teacher_first_name VARCHAR2(50), Teacher_last_name VARCHAR2(50), Teacher_gender VARCHAR2(6), Teacher_grade VARCHAR2(50), Year_of_education NUMBER(3), Teacher_social_security_number VARCHAR2(11), Department_id NUMBER(3), Teacher_nationality VARCHAR2(50), Teacher_age NUMBER(3));
CREATE TABLE Department (Department_id NUMBER(3), Department_name VARCHAR2(50));
CREATE TABLE Student_Course (Student_id NUMBER(3), Course_id NUMBER(3), Registration_number VARCHAR2(50), Registration_date DATE);
CREATE TABLE Course_Teacher (Course_id NUMBER(3), Teacher_id NUMBER(3), Teacher_contract_number VARCHAR2(50), Hour_number_work NUMBER(3), Hour_rate NUMBER(3), Start_date DATE, End_date DATE, Salary as (Hour_number_work*Hour_rate));
CREATE INDEX IDX_Department_name ON Department (Department_name);




ALTER TABLE Student MODIFY (Student_id NUMBER(3) NOT NULL);
ALTER TABLE Student_Course MODIFY (Student_id NUMBER(3) NOT NULL);
ALTER TABLE Student_Course MODIFY (Course_id NUMBER(3) NOT NULL);
ALTER TABLE Course MODIFY (Course_id NUMBER(3) NOT NULL);
ALTER TABLE Course_Teacher MODIFY (Course_id NUMBER(3) NOT NULL);
ALTER TABLE Course_Teacher MODIFY (Teacher_id NUMBER(3) NOT NULL);
ALTER TABLE Teacher MODIFY (Teacher_id NUMBER(3) NOT NULL);
ALTER TABLE Department MODIFY (Department_id NUMBER(3) NOT NULL);
ALTER TABLE Department MODIFY (Department_name VARCHAR(50) NOT NULL);
ALTER TABLE Teacher ADD CONSTRAINT UQ_SSN UNIQUE (Teacher_social_security_number);
ALTER TABLE Student ADD CONSTRAINT UQ_SSN_Student UNIQUE (Student_social_security_number);
ALTER TABLE Course MODIFY Fee_per_credit DEFAULT 175;
ALTER TABLE Teacher ADD CONSTRAINT CK_Teacher_age CHECK (Teacher_age>=24);
ALTER TABLE Student ADD CONSTRAINT CK_Student_gender CHECK (Student_gender='Male' OR Student_gender='Female');



ALTER TABLE Student ADD CONSTRAINT PK_Student PRIMARY KEY (Student_id);
ALTER TABLE Student_Course ADD CONSTRAINT PK_Student_Course PRIMARY KEY (Student_id, Course_id);
ALTER TABLE Course ADD CONSTRAINT PK_Course PRIMARY KEY (Course_id);
ALTER TABLE Course_Teacher ADD CONSTRAINT PK_Course_Teacher PRIMARY KEY (Course_id, Teacher_id);
ALTER TABLE Teacher ADD CONSTRAINT PK_Teacher PRIMARY KEY (Teacher_id);
ALTER TABLE Department ADD CONSTRAINT PK_Department PRIMARY KEY (Department_id);
ALTER TABLE Student_Course ADD CONSTRAINT FK_Student_Course_Student FOREIGN KEY (Student_id) REFERENCES Student(Student_id);
ALTER TABLE  Student_Course ADD CONSTRAINT FK_Student_Course_Course FOREIGN KEY (Course_id) REFERENCES  Course(Course_id);
ALTER TABLE  Course_Teacher ADD CONSTRAINT FK_Course_Teacher_Course FOREIGN KEY (Course_id) REFERENCES  Course(Course_id);
ALTER TABLE  Course_Teacher ADD CONSTRAINT FK_Course_Teacher_Teacher FOREIGN KEY (Teacher_id) REFERENCES  Teacher(Teacher_id);
ALTER TABLE  Teacher ADD CONSTRAINT FK_Teacher_Department FOREIGN KEY (Department_id) REFERENCES  Department(Department_id);

INSERT INTO  Student VALUES (1,'Truong','Pham','Male','111-222-111', 'Vietnamese', 19);
  INSERT INTO  Student VALUES (2,'Thien','Nguyen','Male','111-222-222', 'Vietnamese', 19);
  INSERT INTO  Student VALUES (3,'Hung','Bui','Male','111-222-333', 'Vietnamese', 19);
  INSERT INTO  Student VALUES (4,'Khoa','Nguyen','Male','111-222-444', 'Vietnamese', 19);
  INSERT INTO  Student VALUES (5,'Quang','Nguyen','Male','111-222-555', 'Vietnamese', 19);
  INSERT INTO  Student VALUES (6,'Kiet','Nguyen','Male','111-222-666', 'Vietnamese', 20);
  INSERT INTO  Student VALUES (7,'Dat','Nguyen','Male','111-222-777', 'Vietnamese', 21);
  INSERT INTO  Student VALUES (8,'Duy','Vu','Male','111-222-888', 'Vietnamese', 19);
  INSERT INTO  Student VALUES (9,'Michelle','Williams','Female','111-222-999', 'British', 18);
  INSERT INTO  Student VALUES (10,'Justin','Bieber','Male','111-333-111', 'American', 23);
  INSERT INTO  Student VALUES (11,'Oriana','Pham','Female','111-333-222', 'Canadian', 19);
  INSERT INTO  Student VALUES (12,'Thresh','Alex','Male','111-333-333', 'Brazil', 19);
  INSERT INTO  Student VALUES (13,'Fiora','James','Female','111-333-444', 'Indian', 21);
  INSERT INTO  Student VALUES (14,'Leona','Nguyen','Female','111-333-555', 'British', 20);
  INSERT INTO  Student VALUES (15,'Yuumi','Depp','Female','111-333-666', 'Italian', 21);



  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(1,'Database',50,4,'None', 'None', 'Learning Database');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(2,'OOP',55,4,'Finished Algorithm', 'None', 'Learning C##');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(3,'Algorithm',40,1,'None', 'Museum Science', 'Pseudo Code document');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(4,'PE',35,3,'None', 'Atwater metro', 'Healthy excercise');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(5,'Installation and Config',50,5,'None', 'McGill University', 'Linux_Command');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(6,'Immersion English',60,5,'None', 'McCord Museum', 'Grammar documents');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(7,'Web development',45,3,'Finished Intro Web', 'None', 'Syntax HTMl/CSS_advanced');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(8,'Intro Web',50,4,'None', 'None', 'syntax HTML/CSS');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(9,'Remedial English',40,3,'Finished Immersion', 'None', 'Analysis document');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(10,'French Beginner',30,3,'None', 'Old Port', 'French vocabulary');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(11,'French Intermidiate',35,5,'Finished Beginner', 'None', 'French_grammar');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(12,'Collegial Life',34,5,'None', 'None', 'Online document');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(13,'Operating System',30,3,'None', 'None', 'Window System');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(14,'Computer Architecture',35,5,'None', 'Biodome', 'Hardware List');
  INSERT INTO  Course(Course_id, Course_title, Hour_number, Credits, Prerequisite, Outdoor_activities, Required_document) VALUES(15,'Applied Math',34,5,'None', 'None', 'Math documents');


   INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Computer Science');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Mathematics');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Sport indsutry');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'English literature');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Agriculture');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Environment');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Finance');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Statistics');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Medical');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Tourism');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Hotel Management');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Science');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Designer');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Economics');
  INSERT INTO  Department VALUES (SEQ_Number.NextVal,'Logistics');


   INSERT INTO  Teacher VALUES (1,'Ahri','Akali', 'Female', 'PhD', 21, '111-333-777', 1, 'Chinese', 30);
  INSERT INTO  Teacher VALUES (2,'Braum','Ashan', 'Male', 'Master', 22, '111-333-888', 1, 'Russian', 26);
  INSERT INTO  Teacher VALUES (3,'Caitlyn','Vi', 'Female', 'Bachelor', 24, '111-333-999', 1, 'French', 31);
  INSERT INTO  Teacher VALUES (4,'An','Wong', 'Male', 'Master', 25, '111-444-111', 2, 'Chinese', 55);
  INSERT INTO  Teacher VALUES (5,'Camille','Jay', 'Female', 'PhD', 21, '111-444-222', 2, 'American', 30);
  INSERT INTO  Teacher VALUES (6,'Mundo','Draven', 'Male', 'Master', 22, '111-444-333', 2, 'Bristish', 26);
  INSERT INTO  Teacher VALUES (7,'Ezreal','Pham', 'Male', 'Bachelor', 24, '111-444-444', 3, 'Vietnamese', 35);
  INSERT INTO  Teacher VALUES (8,'Sylvain','Desmarteau', 'Male', 'Master', 25, '111-444-555', 3, 'Russian', 55);
  INSERT INTO  Teacher VALUES (9,'Janna','Ivern', 'Female', 'PhD', 21, '111-444-666', 3, 'Italian', 30);
  INSERT INTO  Teacher VALUES (10,'Jarvan','Jhin', 'Male', 'Master', 22, '111-444-777', 4, 'Russian', 26);
  INSERT INTO  Teacher VALUES (11,'Jinx','Kalista', 'Female', 'Bachelor', 24, '111-444-888', 5, 'French', 31);
  INSERT INTO  Teacher VALUES (12,'Karma','Kayn', 'Female', 'Master', 25, '111-444-999', 6, 'Chinese', 55);
  INSERT INTO  Teacher VALUES (13,'Lee Sin','Leblanc', 'Male', 'PhD', 21, '111-555-111', 7, 'American', 30);
  INSERT INTO  Teacher VALUES (14,'Maokai','Darius', 'Male', 'Master', 22, '111-555-222', 8, 'Bristish', 26);
  INSERT INTO  Teacher VALUES (15,'Nidalee','Neeko', 'Female', 'Bachelor', 24, '111-555-333', 3, 'Vietnamese', 35);


  INSERT INTO  Student_Course VALUES(1,1,'202130169','2022-05-03');
  INSERT INTO  Student_Course VALUES(1,3,'584544544','2022-01-09');
  INSERT INTO  Student_Course VALUES(1,2,'202130169','2022-05-03');
  INSERT INTO  Student_Course VALUES(2,5,'202012343','2021-08-08');
  INSERT INTO  Student_Course VALUES(3,4,'202123232','2022-05-03');
  INSERT INTO  Student_Course VALUES(3,6,'202123232','2022-05-03');
  INSERT INTO  Student_Course VALUES(1,5,'483439343','2021-08-08');
  INSERT INTO  Student_Course VALUES(1,9,'584544544','2022-01-09');
  INSERT INTO  Student_Course VALUES(1,10,'584544544','2022-01-09');
  INSERT INTO  Student_Course VALUES(1,11,'202130169','2022-05-03');
  INSERT INTO  Student_Course VALUES(6,8,'202343334','2022-01-09');
  INSERT INTO  Student_Course VALUES(1,7,'202130169','2022-05-03');
  INSERT INTO  Student_Course VALUES(10,13,'323455434','2022-05-03');
  INSERT INTO  Student_Course VALUES(9,15,'283907896','2022-01-09');
  INSERT INTO  Student_Course VALUES(7,14,'386798767','2022-01-09');



    INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(1,1,'202102348',50,30,'2022-05-10','2022-07-30');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(2,1,'202102348',55,34,'2022-05-10','2022-07-30');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(3,3,'230239790',40,33,'2022-01-11','2022-05-01');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(2,3,'839433433',55,34,'2022-05-10','2022-07-30');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(2,2,'903834343',55,34,'2022-05-10','2022-07-30');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(3,2,'794349343',40,33,'2022-01-11','2022-05-01');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(1,2,'903834343',50,30,'2022-05-10','2022-07-30');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(5,1,'683901620',50,32,'2021-08-10','2021-12-30');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(14,3,'578901231',35,31,'2022-01-11','2022-05-01');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(15,4,'349013675',34,32,'2022-01-11','2022-05-01');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(15,6,'987394343',34,32,'2022-01-11','2022-05-01');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(6,10,'242399434',60,30,'2021-08-10','2021-12-30');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(9,10,'893434976',40,32,'2022-01-11','2022-05-01');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(4,7,'128329856',35,33,'2022-01-11','2022-05-01');
  INSERT INTO  Course_Teacher(Course_id,Teacher_id,Teacher_contract_number, Hour_number_work, Hour_rate, Start_date,End_date) VALUES(4,8,'609182323',35,33,'2022-01-11','2022-05-01');
