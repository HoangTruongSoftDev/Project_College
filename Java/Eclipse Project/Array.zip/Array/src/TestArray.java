import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class TestArray {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1 = {1,2,3};
		ArrayList<Integer> arrayList1 = new ArrayList<Integer>(Arrays.asList(1,2,3));
		System.out.println(arrayList1.get(2));
		ArrayList<Integer> arrayList2 = arrayList1;
		System.out.println(arrayList1 == arrayList2);
		
		String[] array2 = {"truong","hoang"};
		List<String> list1 = new ArrayList<String>();
		
		//Deep copy
		String[] array3 = Arrays.copyOf(array2,array2.length);
		System.out.println("array3 == array2: " + (array3==array2));
		System.out.println("array3.equals(array2): " + array3.equals(array2));
		System.out.println("array3[0].equals(array2[0]): " + array3[0].equals(array2[0]));
		System.out.println("array3[0] == array2[0]: " + (array3[0] == array2[0]));
		array3[0] = "Ngu";
		System.out.println("array2[0]: " + array2[0]);
		
		// Shallow copy
		String[] array4 = array3;
		for (int i=0; i<array3.length;i++) {
			System.out.print(array3[i]+" ");
		}
		for (String element : array4) {
			System.out.print(element+" ");
		}
		array4[1] = "Pham";
		System.out.println("\narray3[1]: "+ array3[1]);
		int[] array5 = {1,2,3,4,5};
		int[] array6 = {1,2,3,4,5};
		array5[0] = 0;
		System.out.println("array6[0]: " + array6[0]);
		
		String name = "hoang";
		System.out.println("name == array2[1]: " + (name == array2[1]));
		
		// Mrs. Michelle's code
		int[] nums = new int[5]; //syntax: datatype[] arr_name = new datatype[size];
		
		nums[0] = 11;
		nums[1] = 22;
		nums[2] = 33;
		nums[3] = 44;
		nums[4] = 55;
		
		System.out.println("nums.length: " + nums.length);
		System.out.println("for iteration: ");
		for(int i = 0; i<nums.length;i++){
			System.out.println(nums[i]);
		}
		System.out.println("foreach iteration: "); // using foreach if you just want to access the element not changing its value
		for (var elem:nums) {
			System.out.println(elem); //elem is a copy of each member of array for each iteration. elem = nums[i], and elem will be killed after the iteration
			elem *= 2;		
			System.out.println(elem);
		}
		
		System.out.println("After changing element: ");
		for (var elem:nums) {
			System.out.println(elem); // the value of elem in here will be different from above			
		}
		
		int a = 5;
		int b = a; //b and a will be independent and carry two different value of 5
		
		int[] nums1 = nums; //shallow copy
		System.out.println("nums1[0] == nums[0]" + (nums1[0] == nums[0])); 
		
		Integer[] nums2 = new Integer[5];
		nums2[0] = 11;
		
		System.out.println("nums2[0] == nums1[0]" + (nums2[0] == nums1[0]));
		
		nums1[0] = 100;
		System.out.println(nums[0]);
		System.out.println(nums2[0]);
		
		int[] nums3 = Arrays.copyOf(nums, nums.length+1);
		nums3[nums3.length-1] = 66;
		nums[0] =111;
		
		System.out.println("Nums: ");
		for(var elem:nums) {
			System.out.println(elem);
		}
		
		System.out.println("Nums2: ");
		for(var elem:nums3) {
			System.out.println(elem);
		}
		
		String[] str1 = {"Truong", "hoang"};
		String[] str2 = Arrays.copyOf(str1, str1.length);
		str1[0] = "Pham";
		System.out.println("Str2[0]: " + str2[0]);
	}

}
