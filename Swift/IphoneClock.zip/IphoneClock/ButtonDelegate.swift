//
//  ButtonDelegate.swift
//  IphoneClock
//
//  Created by english on 2023-11-02.
//

import Foundation
 
protocol ButtonDelegate {
     func refreshButton()
}
