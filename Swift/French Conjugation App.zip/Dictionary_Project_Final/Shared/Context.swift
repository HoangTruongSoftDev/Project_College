//
//  Context.swift
//  Dictionary_Project_Final
//
//  Created by english on 2023-12-06.
//

import Foundation
class Context {
    static var loggedUserToken : String?
}
