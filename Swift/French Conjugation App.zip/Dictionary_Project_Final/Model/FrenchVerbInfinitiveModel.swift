//
//  File.swift
//  FrenchVerbConjugation
//
//  Created by Daniel Carvalho on 15/11/23.
//

import Foundation


struct FrenchVerbInfinitive : Codable {
    
    var present : String?
    var passe : String?
    
}
