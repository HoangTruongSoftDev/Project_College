//
//  enumSegue.swift
//  Dictionary_Project_Final
//
//  Created by english on 2023-11-14.
//

import Foundation

enum Segue {
        
    static let toSignUpViewController = "toSignUpViewController"
    static let toMainViewController = "toMainViewController"
    static let toInformationViewController = "toInformationViewController"
    static let toConjugationViewController = "toConjugationViewController"
    static let toLoginViewController = "toLoginViewController"
}

