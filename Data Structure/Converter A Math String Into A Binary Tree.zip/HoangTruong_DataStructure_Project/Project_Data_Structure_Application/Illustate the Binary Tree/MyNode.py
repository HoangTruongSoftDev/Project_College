

class MyNode: 
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None
    
    #@property
    #def get_data(self):
    #    return self.get_data
    #@get_data.setter
    #def set_data(self, data):
    #    self.__data = data

    #@property
    #def get_left(self):
    #    return self.__left
    #@get_left.setter
    #def set_left(self, left):
    #    self.__left = left

    #@property
    #def get_right(self):
    #    return self.__right
    #@get_right.setter
    #def set_right(self, right):
    #    self.__right = right